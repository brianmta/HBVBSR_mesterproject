<?php
    header('Content-Type: text/html; charset=utf-8');

    function db_connect(){
        $mysqli = new mysqli("mysql80.r3.websupport.hu","vacvillany_admin", "Xh1J0eB!IC", "villanyszereles", 3314);
        if (!$mysqli){
            die("Connection error.".$mysqli->error);
        }
    return $mysqli;
    }
?>