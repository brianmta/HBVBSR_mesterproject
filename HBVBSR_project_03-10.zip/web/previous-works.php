﻿
<!DOCTYPE html>
<html>
	<head>

		<meta http-equiv="content-type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Vác Villanyszerelés</title>
        <link rel="shortcut icon" href="images/logo.2x.png">

		<!-- GOOGLE FONTS : begin -->
		<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic%7cExo+2:400,700&amp;subset=latin,latin-ext" rel="stylesheet" type="text/css">
		<!-- GOOGLE FONTS : end -->

        <!-- STYLESHEETS : begin -->
		<link rel="stylesheet" type="text/css" href="library/css/style.css">
        <link rel="stylesheet" type="text/css" href="library/css/skin/default.css">
		<link rel="stylesheet" type="text/css" href="library/css/custom.css">
		<!-- STYLESHEETS : end -->

        <!--[if lte IE 8]>
			<link rel="stylesheet" type="text/css" href="library/css/oldie.css">
			<script src="library/js/respond.min.js" type="text/javascript"></script>
        <![endif]-->
		<script src="library/js/modernizr.custom.min.js" type="text/javascript"></script>

	</head>
	<body class="m-fixed-header">

		<!-- WRAPPER : begin -->
		<div id="wrapper">

						<!-- HEADER : begin -->
						<header id="header">
							<div class="header-inner">
								<div class="container">
			
									<!-- HEADER BRANDING : begin -->
									<div class="header-branding">
										<div class="branding-inner">
			
											<!-- BRANDING LOGO : begin -->
											<div class="brading-logo">
												<a href="index.php"><img src="images/logo.png" data-hires="images/logo.2x.png" alt="Blue Collar"></a>
											</div>
											<!-- BRANDING LOGO : end -->
			
											<!-- BRANDING INFO : begin -->
											<div class="brading-info">
												<strong>Vollai Attila</strong><br>
												<em>Vác Villanyszerelés</em>
											</div>
											<!-- BRANDING INFO : end -->
			
										</div>
									</div>
									<!-- HEADER BRANDING : end -->
			
									<!-- NAVIGATION TOGGLE : begin -->
									<button class="header-navigation-toggle" type="button"><i class="fa fa-bars"></i></button>
									<!-- NAVIGATION TOGGLE : end -->
			
									<!-- HEADER NAVIGATION : begin -->
									<div class="header-navigation">
										<div class="navigation-inner">
			
											<!-- HEADER MENU : begin -->
											<nav class="header-menu">
												<ul>
													<li>
														<a href="index.php">Főoldal</a>
													</li>
													<li>
														<a href="service-list.php">Szolgáltatások</a>
														<ul>
															<li><a href="service-detail.php">További információ</a></li>
														</ul>
													</li>
													<li class="m-active">
														<a href="portfolio.php">Rólam</a>
														<ul>
															<li><a href="previous-works.php">Korábbi munkáim</a></li>
														</ul>
													</li>
													<li><a href="contact.php">Kapcsolat</a></li>
												</ul>
											</nav>
											<!-- HEADER MENU : end -->
			
										</div>
									</div>
									<!-- HEADER NAVIGATION : end -->
			
								</div>
							</div>
						</header>
						<!-- HEADER : end -->

			<!-- CORE : begin -->
			<div id="core">

				<!-- PAGE TITLE : begin -->
				<div id="page-title" class="m-parallax">

					<!-- PAGE TITLE TOP : begin -->
					<div class="page-title-top">
						<div class="page-title-top-inner">

							<!-- PAGE TITLE TEXT : begin -->
							<div class="page-title-text">
								<div class="container">
									<h1>Korábbi munkáim</h1>
								</div>
							</div>
							<!-- PAGE TITLE TEXT : end -->

						</div>
					</div>
					<!-- PAGE TITLE TOP : end -->

					<!-- PAGE TITLE BOTTOM : begin -->
					<div class="page-title-bottom">
						<div class="container">
							<div class="page-title-bottom-inner">
								<div class="page-title-bottom-inner2">

									<!-- PAGE TITLE BREADCRUMBS : begin -->
									<div class="page-title-breadcrumbs">
										<ul>
											<li><a href="index.php">Főoldal</a></li>
											<li><a href="portfolio.php">Rólam</a></li>
											<li>Korábbi munkáim</li>
										</ul>
									</div>
									<!-- PAGE TITLE BREADCRUMBS : end -->

								</div>
							</div>
						</div>
					</div>
					<!-- PAGE TITLE BOTTOM : end -->

				</div>
				<!-- PAGE TITLE : end -->

				<div class="container">
					<div class="row">
						<div class="col-md-12">

							<!-- PAGE CONTENT : begin -->
							<div id="page-content">

								<!--<h2>Daily Tips For <strong>DIY Enthusiasts</strong></h2>-->
								<p> Tekintse meg a nagyobb munkáimat, ezeken kívül számtalan kissebb munkát is elvégeztem.</p>

								<!-- BLOG LIST PAGE : begin -->
								<div class="blog-list-page">

									<!-- ARTICLE LIST : begin -->
									<div class="c-article-list m-masonry">

										<!-- ARTICLE : begin -->
										<article class="c-article m-cropped">
											<div class="article-inner">
												<div class="article-image">
													<img src="images/article-01-th.jpg" alt="">
												</div>
												<div class="article-content">
													<div class="content-inner">
														<h2 class="article-title">Placeholder}</h2>
														<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nostrum doloremque quia cupiditate tempore, sapiente, nulla error facilis fuga architecto ducimus est quo impedit tempora omnis expedita incidunt repellat? Dicta, magni.</p>
													</div>
												</div>
											</div>
										</article>
										<!-- ARTICLE : end -->

										<!-- ARTICLE : begin -->
										<article class="c-article m-cropped">
											<div class="article-inner">
												<div class="article-image">
													<img src="images/article-01-th.jpg" alt="">
												</div>
												<div class="article-content">
													<div class="content-inner">
														<h2 class="article-title">Placeholder}</h2>
														<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nostrum doloremque quia cupiditate tempore, sapiente, nulla error facilis fuga architecto ducimus est quo impedit tempora omnis expedita incidunt repellat? Dicta, magni.</p>
													</div>
												</div>
											</div>
										</article>
										<!-- ARTICLE : end -->
										<!-- ARTICLE : begin -->
										<article class="c-article m-cropped">
											<div class="article-inner">
												<a id="article3-4"></a>
												<div class="article-image">
													<img src="images/article-01-th.jpg" alt="">
												</div>
												<div class="article-content">
													<div class="content-inner">
														<h2 class="article-title">Placeholder}</h2>
														<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nostrum doloremque quia cupiditate tempore, sapiente, nulla error facilis fuga architecto ducimus est quo impedit tempora omnis expedita incidunt repellat? Dicta, magni.</p>
													</div>
												</div>
											</div>
										</article>
										<!-- ARTICLE : end -->

										<!-- ARTICLE : begin -->
										<article class="c-article m-cropped">
											<div class="article-inner">
												<div class="article-image">
													<img src="images/article-01-th.jpg" alt="">
												</div>
												<div class="article-content">
													<div class="content-inner">
														<h2 class="article-title">Placeholder}</h2>
														<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nostrum doloremque quia cupiditate tempore, sapiente, nulla error facilis fuga architecto ducimus est quo impedit tempora omnis expedita incidunt repellat? Dicta, magni.</p>
													</div>
												</div>
											</div>
										</article>
										<!-- ARTICLE : end -->
										<!-- ARTICLE : begin -->
										<article class="c-article m-cropped">
											<div class="article-inner">
												<a id="article5-6"></a>
												<div class="article-image">
													<img src="images/article-01-th.jpg" alt="">
												</div>
												<div class="article-content">
													<div class="content-inner">
														<h2 class="article-title">Placeholder}</h2>
														<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nostrum doloremque quia cupiditate tempore, sapiente, nulla error facilis fuga architecto ducimus est quo impedit tempora omnis expedita incidunt repellat? Dicta, magni.</p>
													</div>
												</div>
											</div>
										</article>
										<!-- ARTICLE : end -->
										<!-- ARTICLE : begin -->
										<article class="c-article m-cropped">
											<div class="article-inner">
												<div class="article-image">
													<img src="images/article-01-th.jpg" alt="">
												</div>
												<div class="article-content">
													<div class="content-inner">
														<h2 class="article-title">{Placeholder}</h2>
														<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nostrum doloremque quia cupiditate tempore, sapiente, nulla error facilis fuga architecto ducimus est quo impedit tempora omnis expedita incidunt repellat? Dicta, magni.</p>
													</div>
												</div>
											</div>
										</article>
										<!-- ARTICLE : end -->

									</div>
									<!-- ARTICLE LIST : end -->

									<!-- PAGINATION : begin 
									<div class="c-pagination">
										<ul>
											<li class="pagination-prev"><a href="#" class="c-button m-outline"><i class="fa fa-chevron-left"></i></a></li>
											<li><a href="#" class="c-button m-outline">1</a></li>
											<li class="m-active"><a href="#" class="c-button m-outline">2</a></li>
											<li><a href="#" class="c-button m-outline">3</a></li>
											<li class="pagination-next"><a href="#" class="c-button m-outline"><i class="fa fa-chevron-right"></i></a></li>
										</ul>
									</div>-->
									<!-- PAGINATION : end -->

								</div>
								<!-- BLOG LIST PAGE : end -->

							</div>
							<!-- PAGE CONTENT : end -->
						</div>
						<!--<div class="col-md-3">

							<hr class="c-divider m-size-large m-type-2 hidden-lg hidden-md">

							<!-- SIDEBAR : sidebar -->
							<div id="sidebar">
								<div class="sidebar-widget-list">

									<!-- SEARCH WIDGET : begin 
									<div class="widget search-widget">
										<div class="widget-inner">
											<div class="widget-content">

												<form class="c-search-form" action="search-results.php">
													<div class="form-fields">
														<input type="text" placeholder="Search on site...">
														<button type="submit"><i class="fa fa-search"></i></button>
													</div>
												</form>

											</div>
										</div>
									</div>-->
									<!-- SEARCH WIDGET : end -->

									<!-- CATEGORIES WIDGET : begin 
									<div class="widget links-widget">
										<div class="widget-inner">
											<h3 class="widget-title">Categories</h3>
											<ul>
												<li><a href="#">Kitchen Tips</a></li>
												<li class="m-active"><a href="#">DIY Repairs</a></li>
												<li><a href="#">Renovation 101</a></li>
												<li><a href="#">Roofing 101</a></li>
												<li><a href="#">Plumbing 101</a></li>
											</ul>
										</div>
									</div>-->
									<!-- CATEGORIES WIDGET : end -->

									<!-- TWITTER WIDGET : begin
									<div class="widget twitter-widget">
										<div class="widget-inner">
											<h3 class="widget-title">Twitter Feed</h3>
											<div class="widget-content">

												 create your own Twitter widget at https://twitter.com/settings/widgets (you have to be logged in to your Twitter account) 
												<a class="twitter-timeline" href="https://twitter.com/LSVRthemes" data-widget-id="552135621662474240">Tweets by @LSVRthemes</a>
												<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
                                                 -->
											</div>
										</div>
									</div>
									<!-- TWITTER WIDGET : end -->

								</div>
							</div>
							<!-- SIDEBAR : end -->

						</div>-->
					</div>
				</div>

			</div>
			<!-- CORE : end -->

			<!-- FOOTER : begin -->
			<div id="footer" class="m-parallax">

				<!-- FOOTER INNER : begin -->
				<div class="footer-inner">
					<div class="container">

						<!-- BOTTOM PANEL : begin -->
						<div id="bottom-panel">
							<div class="row">
								<div class="col-md-4">

									<!-- TEXT WIDGET : begin -->
									<div class="widget text-widget">
										<div class="widget-inner">
											<h3 class="widget-title"><strong>Rólam</strong></h3>
											<div class="widget-content">

												<p><strong>Vác Villanyszerelés</strong> <br>
												<strong>Elektronikai eszközök</strong> javítása, <strong>lámpák</strong> beszerelése, hálózat <strong>kiépítés,</strong> és <strong>újjáépítés.</strong></p>

											</div>
										</div>
									</div>
									<!-- TEXT WIDGET : end -->

									<hr class="c-divider hidden-lg hidden-md">

								</div>
								<div class="col-md-4">

									<!-- TEXT WIDGET (CONTACT) : begin -->
									<div class="widget text-widget">
										<div class="widget-inner">
											<h3 class="widget-title"><strong>Elérhetőségek</strong></h3>
											<div class="widget-content">

												<p>Telefon: <strong>(123) 456 789</strong>
													<br> Elérhetőség: <strong>Hétköznap 10:00-18:00</strong>
												<br>
												</p>

											</div>
										</div>
									</div>
									<!-- TEXT WIDGET (CONTACT) : end -->

									<hr class="c-divider hidden-lg hidden-md">

								</div>
								<div class="col-md-4">

									<!-- SUBSCRIBE WIDGET : begin -->
									<div class="widget subscribe-widget">
										<div class="widget-inner">
											<h3 class="widget-title">Írj nekem <strong>Emailt </strong>bármikor:</h3>
											<div class="widget-content">

													Lépj velem kapcsolatba:
													<strong><a href="mailto:PLACEHOLDER.EMAIL.COM">PLACEHOLDER.EMAIL.COM</a></strong>
													<br>
													<br>
													<!-- EZ EGY MÁSIK FUNKCIÓ IDE MAJD EGY OLYAN EMAIL KÉNE AMI ÁT VISZ A CONTACT FORMBA
														PL: BEÍROD AZ EMAIL CÍMEDET ÉS A KÜLDÉSGOMBRA KATTINTA ÁTVISZ A CONTACT.php-RE ÉS BEÍRJA AZT AZ
														EMAILT AMIT A FELHASZNÁLÓ MEGADOTT, KÉSÖBB, VAGY LEHET NEM IS KELL
												<form class="subscribe-widget-form" action="http://lsvr.us14.list-manage.com/subscribe/post-json?u=8291218baaf54ddfd7dbc6016&id=f3e5d696dc&c=?" method="get">

													 VALIDATION ERROR MESSAGE : begin 
													<p style="display: none;" class="c-alert-message m-warning m-validation-error"><i class="ico fa fa-exclamation-circle"></i>Email address is required.</p>
													<!-- VALIDATION ERROR MESSAGE : end 

													<!-- SENDING REQUEST ERROR MESSAGE : begin 
													<p style="display: none;" class="c-alert-message m-warning m-request-error"><i class="ico fa fa-exclamation-circle"></i>There was a connection problem. Try again later.</p>
													<!-- SENDING REQUEST ERROR MESSAGE : end 

													<!-- SUCCESS MESSAGE : begin 
													<p style="display: none;" class="c-alert-message m-success"><i class="ico fa fa-check-circle"></i><strong>Sent successfully.</strong></p>
													<!-- SUCCESS MESSAGE : end 

													<div class="input-box">
														<input class="email-input m-required m-email" name="EMAIL" type="text" placeholder="Your email address here" title="Your email address here">
														<button class="submit-btn" type="submit" title="Subscribe"><i class="fa fa-chevron-right"></i></button>
													</div>

												</form>
											-->
											</div>
										</div>
									</div>
									<!-- SUBSCRIBE WIDGET : end -->

								</div>
							</div>
						</div>
						<!-- BOTTOM PANEL : end -->

						<div class="row">
							<div class="col-md-6 col-md-push-6">

							</div>
							<div class="col-md-6 col-md-pull-6">


							</div>
						</div>

					</div>
				</div>
				<!-- FOOTER INNER : end -->

			</div>
			<!-- FOOTER : end -->

		</div>
		<!-- WRAPPER : END -->

		<!-- SCRIPTS : begin -->
		<script src="library/js/jquery-1.9.1.min.js" type="text/javascript"></script>
		<script src="library/js/third-party.js" type="text/javascript"></script>
		<script src="library/js/library.js" type="text/javascript"></script>
		<script src="library/js/scripts.js" type="text/javascript"></script>
		<!-- SCRIPTS : end -->

	</body>
</html>