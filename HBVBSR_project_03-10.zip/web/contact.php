﻿<?php 
    require_once ('ajax/db_connect.php');
?>


<!DOCTYPE html>
<html>
	<head>

	<meta http-equiv="content-type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Vác Villanyszerelés</title>
        <link rel="shortcut icon" href="images/logo.2x.png"> 

		<!-- GOOGLE FONTS : begin -->
		<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic%7cExo+2:400,700&amp;subset=latin,latin-ext" rel="stylesheet" type="text/css">
		<!-- GOOGLE FONTS : end -->

        <!-- STYLESHEETS : begin -->
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="library/css/style.css">
        	<link rel="stylesheet" type="text/css" href="library/css/skin/default.css">
		<link rel="stylesheet" type="text/css" href="library/css/custom.css">
		<!-- STYLESHEETS : end -->

        <!--[if lte IE 8]>
			<link rel="stylesheet" type="text/css" href="library/css/oldie.css">
			<script src="library/js/respond.min.js" type="text/javascript"></script>
        <![endif]-->
	

	<!-- CAPTCHA V2 : begin -->
		<script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<!-- CAPTCHA V2 : end -->

	</head>
	<body class="m-fixed-header">

		<!-- WRAPPER : begin -->
		<div id="wrapper">

			<!-- HEADER : begin -->
			<header id="header">
				<div class="header-inner">
					<div class="container">

						<!-- HEADER BRANDING : begin -->
						<div class="header-branding">
							<div class="branding-inner">

								<!-- BRANDING LOGO : begin -->
								<div class="brading-logo">
									<a href="index.php"><img src="images/logo.png" data-hires="images/logo.2x.png" alt="Blue Collar"></a>
								</div>
								<!-- BRANDING LOGO : end -->

								<!-- BRANDING INFO : begin -->
								<div class="brading-info">
									<strong>Vollai Attila</strong><br>
									<em>Vác Villanyszerelés</em>
								</div>
								<!-- BRANDING INFO : end -->

							</div>
						</div>
						<!-- HEADER BRANDING : end -->

						<!-- NAVIGATION TOGGLE : begin -->
						<button class="header-navigation-toggle" type="button"><i class="fa fa-bars"></i></button>
						<!-- NAVIGATION TOGGLE : end -->

						<!-- HEADER NAVIGATION : begin -->
						<div class="header-navigation">
							<div class="navigation-inner">

								<!-- HEADER MENU : begin -->
								<nav class="header-menu">
									<ul>
										<li>
											<a href="index.php">Főoldal</a>
										</li>
										<li>
											<a href="service-list.php">Szolgáltatások</a>
											<ul>
												<li><a href="service-detail.php">További információ</a></li>
											</ul>
										</li>
										<li>
											<a href="portfolio.php">Rólam</a>
											<ul>
												<li><a href="previous-works.php">Korábbi munkáim</a></li>
											</ul>
										</li>
										<li class="m-active"><a href="contact.php">Kapcsolat</a></li>
									</ul>
								</nav>
								<!-- HEADER MENU : end -->

							</div>
						</div>
						<!-- HEADER NAVIGATION : end -->

					</div>
				</div>
			</header>
			<!-- HEADER : end -->

			<!-- CORE : begin -->
			<div id="core">

				<!-- PAGE TITLE : begin -->
				<div id="page-title" class="m-parallax">

					<!-- PAGE TITLE TOP : begin -->
					<div class="page-title-top">
						<div class="page-title-top-inner">

							<!-- PAGE TITLE TEXT : begin -->
							<div class="page-title-text">
								<div class="container">
									<h1>Kapcsolat</h1>
								</div>
							</div>
							<!-- PAGE TITLE TEXT : end -->

						</div>
					</div>
					<!-- PAGE TITLE TOP : end -->

					<!-- PAGE TITLE BOTTOM : begin -->
					<div class="page-title-bottom">
						<div class="container">
							<div class="page-title-bottom-inner">
								<div class="page-title-bottom-inner2">

									<!-- PAGE TITLE BREADCRUMBS : begin -->
									<div class="page-title-breadcrumbs">
										<ul>
											<li><a href="index.php">Főoldal</a></li>
											<li>Kapcsolat</li>
										</ul>
									</div>
									<!-- PAGE TITLE BREADCRUMBS : end -->

								</div>
							</div>
						</div>
					</div>
					<!-- PAGE TITLE BOTTOM : end -->

				</div>
				<!-- PAGE TITLE : end -->

				<div class="container">

					<!-- PAGE CONTENT : begin -->
					<div id="page-content">
								<div class="container">
									<div class="col-sm-12 row">
									  <div class="col-sm-4">
										<div class="c-icon-block">
											<i class="im im-compass"></i>
											<h3>A hatásköröm:</h3>
											<p>Vác és 25 kilóméteres környéke<br>
										</div>
									  </div>
									  <div class="col-sm-4">
										<div class="c-icon-block">
											<i class="im im-clock2"></i>
											<h3>Nyitási idők</h3>
											<p><strong>Hét. - Pén.:</strong> 10am - 6pm<br>
											<strong>Hétvégente:</strong> Zárva</p>
										</div>
									  </div>
									  <div class="col-sm-4">
										<div class="c-icon-block">
											<i class="im im-phone"></i>
											<h3>Hétköznap 10-18 között</h3>
											<p><strong>Tel.:</strong> (123) 456 789<br>
											<strong>Email:</strong> <a href="mailto:PLACEHOLDER.EMAIL.COM">PLACEHOLDER.EMAIL.COM</a></p>
										</div>
									  </div>
									</div>
								  </div>
								<br><br>
								<hr class="c-divider m-transparent hidden-lg hidden-md">

						<hr class="c-divider m-size-small">

						<br><br>
						<h2>Adja le <strong>rendelését</strong> most!</h2>

						<!-- CONTACT FORM : begin -->
						<form class="default-form m-ajax-form" action="ajax/insert.php" method="post" onsubmit="return validateRecaptcha();">
							<input type="hidden" name="contact-form">

							<!-- FORM VALIDATION ERROR MESSAGE : begin -->
							<p class="c-alert-message m-warning m-validation-error" style="display: none;"><i class="ico fa fa-exclamation-circle"></i>Kérem töltse ki megfelelően az összes kötelező (*) mezőt!</p>
							<!-- FORM VALIDATION ERROR MESSAGE : end -->

							<!-- SENDING REQUEST ERROR MESSAGE : begin -->
							<p class="c-alert-message m-warning m-request-error" style="display: none;"><i class="ico fa fa-exclamation-circle"></i>Probléma volt a kapcsolat teremtés során, kérem próbálkozzon újra később.</p>
							<!-- SENDING REQUEST ERROR MESSAGE : end -->

							<div class="alert alert-danger" role="alert" style="display:none" id="recaptcha_error_msg">
								Kérem igazolja, hogy Ön nem egy robot!
							</div>
							
							<div class="alert alert-success" role="alert" style="display:none" id="form_success_msg">
								Megrendelés sikeresen leadva! Hamarosan értesíteni fogom a megadott elérhetőségek egyikén.
							</div>
							
							<div class="row">
								<div class="col-sm-4">

											<!-- SURNAME FIELD : begin -->

											<div class="form-field">
												<label for="contact_name">Név<span>*</span></label>
												<input placeholder="Pl.: Teszt Elek" id="contact_name" name="contact_name" class="m-required" required>
											</div>

											<!-- SURNAME FIELD : end -->

											<!-- EMAIL FIELD : begin -->

											<div class="form-field">
												<label for="contact_email">E-mail cím<span>*</span></label>
												<input type="email" placeholder="Pl.: tesztelek@gmail.com" id="contact_email" name="contact_email" class="m-required m-email" required>
											</div>

											<!-- EMAIL FIELD : end -->

											<!-- PHONE FIELD : begin -->

											<div class="form-field">
												<label for="contact_phone">Telefon<span>*</span></label>
												<input type="tel" placeholder="Pl.: +36301234567 vagy 06301234567" id="contact_phone" name="contact_phone" class="m-required" required>
											</div>

											<!-- PHONE FIELD : end -->

								</div>
								<div class="col-sm-4">

											<!-- CITY FIELD : begin -->
											
											<div class="form-field">
												<label for="contact_city">Város<span>*</span></label>
												<select id="contact_city" name="contact_city" class="m-required" required>
													<option value="" disabled selected>Kérem válasszon!</option>	
													<?php 
														$mysqli = db_connect();
														$sql = "SELECT id, varos FROM varosok ORDER BY varos";
														$rows = $mysqli->query($sql);
															while ($row = $rows->fetch_assoc()){
																echo '<option value="'.$row['id'].'">'.$row['varos'].'</option>';
															}
														mysqli_close($mysqli);
													?>	
												</select>
											</div>

											<!-- CITY FIELD : end -->
											
											<!-- JOB TYPE FIELD : begin -->

											<div class="form-field">
												<label for="contact_job">Munka jellege<span>*</span></label>
												<select id="contact_job" name="contact_job" class="m-required" required>
													<option value="" disabled selected>Kérem válasszon!</option>
													<?php 
														$mysqli = db_connect();
														$sql = "SELECT id, megnevezes FROM munka_jell ORDER BY megnevezes";
														$rows = $mysqli->query($sql);
															while ($row = $rows->fetch_assoc()){
																echo '<option value="'.$row['id'].'">'.$row['megnevezes'].'</option>';
															}
														mysqli_close($mysqli);
													?>
												</select>
											</div>

											<!-- JOB TYPE FIELD : end -->
														
								</div>
								<div class="col-sm-4">	

										<!-- ADDRESS FIELD : begin -->

										<div class="form-field">
											<label for="contact_address">Cím<span>*</span></label>
											<input type="text" placeholder="Pl.: Petőfi Sándor utca 1." id="contact_address" name="contact_address" class="m-required" required>
										</div>

										<!-- ADDRESS FIELD : end -->


										<!-- MESSAGE FIELD : begin -->
										<div class="form-field">
											<label for="contact_message">Üzenet</label>
											<textarea placeholder="Ide írja üzenetét!" id="contact_message" name="contact_message" style="resize: none;"></textarea>
										</div>

										<!-- MESSAGE FIELD : end -->
								</div>										
							</div>

							<br><br><br>

							<!-- CAPTCHA V2 FIELD : begin -->

							<div align="center" class="g-recaptcha m-required" data-sitekey="6Lc_cX0kAAAAAOSX7Dik61RvE7fYHLS16ma3gBkD"></div>

							<!-- CAPTCHA V2 FIELD : end -->

							<br>

							<!-- SUBMIT BUTTON : begin -->
								
							<div style="text-align:center">
								<button class="submit-btn c-button btn btn-outline-secondary" type="submit" data-label="Send Message" data-loading-label="Feldolgozás...">Küldés</button>
							</div>

							<!-- SUBMIT BUTTON : end -->

						</form>
						<!-- CONTACT FORM : end -->

					</div>
					<!-- PAGE CONTENT : end -->

				</div>

			</div>
			<!-- CORE : end -->

			<!-- FOOTER : begin -->
			<div id="footer" class="m-parallax">

				<!-- FOOTER INNER : begin -->
				<div class="footer-inner">
					<div class="container">

						<!-- BOTTOM PANEL : begin -->
						<div id="bottom-panel">
							<div class="row">
								<div class="col-md-4">

									<!-- TEXT WIDGET : begin -->
									<div class="widget text-widget">
										<div class="widget-inner">
											<h3 class="widget-title"><strong>Rólam</strong></h3>
											<div class="widget-content">

												<p><strong>Vác Villanyszerelés</strong> <br>
												<strong>Elektronikai eszközök</strong> javítása, <strong>lámpák</strong> beszerelése, hálózat <strong>kiépítés,</strong> és <strong>újjáépítés.</strong></p>

											</div>
										</div>
									</div>
									<!-- TEXT WIDGET : end -->

									<hr class="c-divider hidden-lg hidden-md">

								</div>
								<div class="col-md-4">

									<!-- TEXT WIDGET (CONTACT) : begin -->
									<div class="widget text-widget">
										<div class="widget-inner">
											<h3 class="widget-title"><strong>Elérhetőségek</strong></h3>
											<div class="widget-content">

												<p>Telefon: <strong>(123) 456 789</strong>
													<br> Elérhetőség: <strong>Hétköznap 10:00-18:00</strong>
												<br>
												</p>

											</div>
										</div>
									</div>
									<!-- TEXT WIDGET (CONTACT) : end -->

									<hr class="c-divider hidden-lg hidden-md">

								</div>
								<div class="col-md-4">

									<!-- SUBSCRIBE WIDGET : begin -->
									<div class="widget subscribe-widget">
										<div class="widget-inner">
											<h3 class="widget-title">Írj nekem <strong>Emailt </strong>bármikor:</h3>
											<div class="widget-content">

													Lépj velem kapcsolatba:
													<strong><a href="mailto:PLACEHOLDER.EMAIL.COM">PLACEHOLDER.EMAIL.COM</a></strong>
													<br>
													<br>
											</div>
										</div>
									</div>
									<!-- SUBSCRIBE WIDGET : end -->

								</div>
							</div>
						</div>
						<!-- BOTTOM PANEL : end -->

						<div class="row">
							<div class="col-md-6 col-md-push-6">

							</div>
							<div class="col-md-6 col-md-pull-6">


							</div>
						</div>

					</div>
				</div>
				<!-- FOOTER INNER : end -->

			</div>
			<!-- FOOTER : end -->

		</div>
		<!-- WRAPPER : END -->

		<!-- SCRIPTS : begin -->
		
		<script>
			function validateRecaptcha() {
				var response = grecaptcha.getResponse();
				if (response.length === 0) {
					document.getElementById("recaptcha_error_msg").style.display="block";
				return false;
				} else {
					document.getElementById("recaptcha_error_msg").style.display="none";
					document.getElementById("form_success_msg").style.display="block";
					return true;
				}
			}
		</script>
		<script src="library/js/jquery-1.9.1.min.js" type="text/javascript"></script>
		<script src="library/js/third-party.js" type="text/javascript"></script>
		<!--<script src="library/js/library.js" type="text/javascript"></script>-->
		<script src="library/js/scripts.js" type="text/javascript"></script>
		<script src='https://www.google.com/recaptcha/api.js?onload=reCaptchaCallback&render=explicit'></script>
		<!-- SCRIPTS : end -->

	</body>
</html>