﻿
<!DOCTYPE html>
<html>
	<head>

		<meta http-equiv="content-type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Vác Villanyszerelés</title>
        <link rel="shortcut icon" href="images/logo.2x.png">

		<!-- GOOGLE FONTS : begin -->
		<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic%7cExo+2:400,700&amp;subset=latin,latin-ext" rel="stylesheet" type="text/css">
		<!-- GOOGLE FONTS : end -->

        <!-- STYLESHEETS : begin -->
		<link rel="stylesheet" type="text/css" href="library/css/style.css">
        <link rel="stylesheet" type="text/css" href="library/css/skin/default.css">
		<link rel="stylesheet" type="text/css" href="library/css/custom.css">
		
		<!-- STYLESHEETS : end -->

        <!--[if lte IE 8]>
			<link rel="stylesheet" type="text/css" href="library/css/oldie.css">
			<script src="library/js/respond.min.js" type="text/javascript"></script>
        <![endif]-->
		<script src="library/js/modernizr.custom.min.js" type="text/javascript"></script>

	</head>
	<body class="m-fixed-header">

		<!-- WRAPPER : begin -->
		<div id="wrapper">

					<!-- HEADER : begin -->
					<header id="header">
						<div class="header-inner">
							<div class="container">
		
								<!-- HEADER BRANDING : begin -->
								<div class="header-branding">
									<div class="branding-inner">
		
										<!-- BRANDING LOGO : begin -->
										<div class="brading-logo">
											<a href="index.php"><img src="images/logo.png" data-hires="images/logo.2x.png" alt="Blue Collar"></a>
										</div>
										<!-- BRANDING LOGO : end -->
		
										<!-- BRANDING INFO : begin -->
										<div class="brading-info">
											<strong>Vollai Attila</strong><br>
											<em>Vác Villanyszerelés</em>
										</div>
										<!-- BRANDING INFO : end -->
		
									</div>
								</div>
								<!-- HEADER BRANDING : end -->
		
								<!-- NAVIGATION TOGGLE : begin -->
								<button class="header-navigation-toggle" type="button"><i class="fa fa-bars"></i></button>
								<!-- NAVIGATION TOGGLE : end -->
		
								<!-- HEADER NAVIGATION : begin -->
								<div class="header-navigation">
									<div class="navigation-inner">
		
										<!-- HEADER MENU : begin -->
										<nav class="header-menu">
											<ul>
												<li class="m-active">
													<a href="index.php">Főoldal</a>
												</li>
												<li>
													<a href="service-list.php">Szolgáltatások</a>
													<ul>
														<li><a href="service-detail.php">További információ</a></li>
													</ul>
												</li>
												<li>
													<a href="portfolio.php">Rólam</a>
													<ul>
														<li><a href="previous-works.php">Korábbi munkáim</a></li>
													</ul>
												</li>
												<li><a href="contact.php">Kapcsolat</a></li>
											</ul>
										</nav>
										<!-- HEADER MENU : end -->
		
									</div>
								</div>
								<!-- HEADER NAVIGATION : end -->
		
							</div>
						</div>
					</header>
					<!-- HEADER : end -->
			<!-- CORE : begin -->
			<div id="core">

				<!-- PAGE TITLE : begin -->
				<div id="page-title" class="m-parallax">

					<!-- PAGE TITLE TOP : begin -->
					<div class="page-title-top">
						<div class="page-title-top-inner">

							<!-- PAGE TITLE TEXT : begin -->
							<div class="page-title-text">
								<div class="container">
									<h1>Villanyszerelés<br><strong>Vácon és környékén</strong>!</h1>
								</div>
							</div>
							<!-- PAGE TITLE TEXT : end -->

						</div>
					</div>
					<!-- PAGE TITLE TOP : end -->

					<!-- PAGE TITLE BOTTOM : begin -->
					<div class="page-title-bottom">
						<div class="container">
							<div class="page-title-bottom-inner">
								<div class="page-title-bottom-inner2">

									<!-- PAGE TITLE BAR : begin -->
									<div class="page-title-bar">
										<div class="page-title-bar-inner">

											<ul class="page-title-bar-left">
												<li><i class="fa fa-phone"></i><strong>(123) 456 789</strong></li>
												<li><i class="fa fa-envelope-o"></i><strong><a href="mailto:vollai.attila.villanyszereles@gmail.com">  vollai.attila.villanyszereles@gmail.com</a></strong></li>
												<li class="social">
													<ul>
														<li><a href="https://api.whatsapp.com/"><i class="fa fa-whatsapp"></i></a></li>
														<li><a href="https://hu-hu.facebook.com/"><i class="fa fa-facebook"></i></a></li>
													</ul>
												</li>
											</ul>

											<div class="page-title-bar-right">
												<a href="contact.php" class="c-button m-type-2 m-size-medium">Lássunk munkához!</a>
											</div>

										</div>
									</div>
									<!-- PAGE TITLE BAR : end -->

								</div>
							</div>
						</div>
					</div>
					<!-- PAGE TITLE BOTTOM : end -->

				</div>
				<!-- PAGE TITLE : end -->

				<!-- PAGE CONTENT : begin -->
				<div id="page-content">

					<!-- INTRO SECTION : begin -->
					<section class="c-section">
						<div class="section-inner">
							<div class="container">

								<div class="row">
									<div class="col-md-4">

										<p class="hidden-sm hidden-xs"><img src="images/home-handyman-01.png" class="margin-top-negative-70" alt=""></p>

									</div>
									<div class="col-md-8">

										<hr class="c-divider m-transparent m-size-medium hidden-xs hidden-sm hidden-md">
										<h2><strong>Több mint 20 évnyi tapasztalat</strong><br>villanyszerelésben és ház körüli munkákban</h2>
										<p>Bejelentett munkahely mellett egyéni vállalkozóként is napi szinten foglalkozok villanyszereléssel, több mint 20 éve.</p>
										<p><a href="portfolio.php" class="c-button m-type-2 m-size-medium">Tudj meg többet rólam!</a></p>

									</div>
								</div>

							</div>
						</div>
					</section>
					<!-- INTRO SECTION : end -->

					<!-- FEATURES SECTION : begin -->
					<section class="c-section">
						<div class="section-inner">
							<div class="container">

								<hr class="c-divider m-size-medium">

								<div class="row">
									<div class="col-md-4">

										<!-- FEATURE : begin -->
										<div class="c-feature">
											<i class="feature-icon im im-license"></i>
											<h3 class="feature-title">Tanusítványok</h3>
											<div class="feature-text">
												<p>{TANUSÍTVÁNYOK IDE}</p>
											</div>
										</div>
										<!-- FEATURE : end -->

										<hr class="c-divider m-transparent hidden-lg hidden-md">

									</div>
									<div class="col-md-4">

										<!-- FEATURE : begin -->
										<div class="c-feature">
											<i class="feature-icon im im-clock2"></i>
											<h3 class="feature-title">Korábbi munkák</h3>
											<div class="feature-text">
												<p>{KORÁBBI MUNKÁK LINK IDE}</p>
											</div>
										</div>
										<!-- FEATURE : end -->

										<hr class="c-divider m-transparent hidden-lg hidden-md">

									</div>
									<div class="col-md-4">

										<!-- FEATURE : begin -->
										<div class="c-feature">
											<i class="feature-icon im im-cash"></i>
											<h3 class="feature-title">Tisztességes árak</h3>
											<div class="feature-text">
												<p>{ÁRAK FEATURE IDE}</p>
											</div>
										</div>
										<!-- FEATURE : end -->

									</div>
								</div>

							</div>
						</div>
					</section>
					<!-- FEATURES SECTION : end -->

					<!-- TESTIMONIALS SECTION : begin -->
					<section class="c-parallax-section m-dynamic m-has-overlay" style="background-image: url( 'images/testimonials-section-bg.jpg' );">
						<div class="section-inner">
							<div class="container">

								<h2>Néhány tapasztalat <strong>elöző ügyfeleimtől</strong></h2>
								<div class="row">
									<div class="col-md-4">

										<!-- TESTIMONIAL : begin -->
										<div class="c-testimonial">
											<blockquote>
												<p>{PLACEHOLDER COMMENT}</p>
												<footer><cite><strong>{PLACEHOLDER NAME}</strong>, {PLACEHOLDER OCCUPATION}</cite></footer>
											</blockquote>
										</div>
										<!-- TESTIMONIAL : end -->

										<hr class="c-divider hidden-lg hidden-md">

									</div>
									<div class="col-md-4">

										<!-- TESTIMONIAL : begin -->
										<div class="c-testimonial">
											<blockquote>
												<p>{PLACEHOLDER COMMENT}</p>
												<footer><cite><strong>{PLACEHOLDER NAME}</strong>, {PLACEHOLDER OCCUPATION}</cite></footer>
											</blockquote>
										</div>
										<!-- TESTIMONIAL : end -->

										<hr class="c-divider hidden-lg hidden-md">

									</div>
									<div class="col-md-4">

										<!-- TESTIMONIAL : begin -->
										<div class="c-testimonial">
											<blockquote>
												<p>{PLACEHOLDER COMMENT}</p>
												<footer><cite><strong>{PLACEHOLDER NAME}</strong>, {PLACEHOLDER OCCUPATION}</cite></footer>
											</blockquote>
										</div>
										<!-- TESTIMONIAL : end -->

									</div>
								</div>

							</div>
						</div>
					</section>
					<!-- TESTIMONIALS SECTION : end -->

					<!-- ARTICLES SECTION : begin -->
					<section class="c-section">
						<div class="section-inner">
							<div class="container">

								<h2>Tekintsd meg <strong>korábbi munkáimat</strong>!</h2>

								<!-- CAROUSEL : begin -->
								<div class="c-carousel" data-autoplay="0" data-loop="false"
									data-items-show="3" data-items-under-1199="3" data-items-under-991="2" data-items-under-767="2" data-items-under-480="1">
									<div class="c-carousel-items">

										<!-- ARTICLE LIST: begin -->
										<div class="c-article-list">


											<!-- ARTICLE : begin -->
											<article class="c-article m-cropped">
												<div class="article-inner">
													<div class="article-image">
														<a href="previous-works.php"><img src="images/article-01-th.jpg" alt=""></a>
													</div>
													<div class="article-content">
														<div class="content-inner">
															<h2 class="article-title"><a href="previous-works.php">Article Title</a></h2>
														<a href="previous-works.php"><p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Earum temporibus eum, nihil quidem perferendis, culpa maiores reiciendis quo porro in, minus delectus error facilis molestiae omnis nobis tempore. Impedit, et?</p> </a>
														</div>
													</div>
												</div>
											</article>
											<!-- ARTICLE : end -->

											<!-- ARTICLE : begin -->
											<article class="c-article m-cropped">
												<div class="article-inner">
													<div class="article-image">
														<a href="previous-works.php"><img src="images/article-01-th.jpg" alt=""></a>
													</div>
													<div class="article-content">
														<div class="content-inner">
															<h2 class="article-title"><a href="previous-works.php">Article Title</a></h2>
														<a href="previous-works.php"><p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Earum temporibus eum, nihil quidem perferendis, culpa maiores reiciendis quo porro in, minus delectus error facilis molestiae omnis nobis tempore. Impedit, et?</p> </a>
														</div>
													</div>
												</div>
											</article>
											<!-- ARTICLE : end -->

											<!-- ARTICLE : begin -->
											<article class="c-article m-cropped">
												<div class="article-inner">
													<div class="article-image">
														<a href="previous-works.php#article3-4"><img src="images/article-01-th.jpg" alt=""></a>
													</div>
													<div class="article-content">
														<div class="content-inner">
															<h2 class="article-title"><a href="previous-works.php#article3-4">Article Title</a></h2>
														<a href="previous-works.php#article3-4"><p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Earum temporibus eum, nihil quidem perferendis, culpa maiores reiciendis quo porro in, minus delectus error facilis molestiae omnis nobis tempore. Impedit, et?</p> </a>
														</div>
													</div>
												</div>
											</article>
											<!-- ARTICLE : end -->


											<!-- ARTICLE : begin -->
											<article class="c-article m-cropped">
												<div class="article-inner">
													<div class="article-image">
														<a href="previous-works.php#article3-4"><img src="images/article-01-th.jpg" alt=""></a>
													</div>
													<div class="article-content">
														<div class="content-inner">
															<h2 class="article-title"><a href="previous-works.php#article3-4">Article Title</a></h2>
														<a href="previous-works.php#article3-4"><p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Earum temporibus eum, nihil quidem perferendis, culpa maiores reiciendis quo porro in, minus delectus error facilis molestiae omnis nobis tempore. Impedit, et?</p> </a>
														</div>
													</div>
												</div>
											</article>
											<!-- ARTICLE : end -->

											<!-- ARTICLE : begin -->
											<article class="c-article m-cropped">
												<div class="article-inner">
													<div class="article-image">
														<a href="previous-works.php#article5-6"><img src="images/article-01-th.jpg" alt=""></a>
													</div>
													<div class="article-content">
														<div class="content-inner">
															<h2 class="article-title"><a href="previous-works.php#article5-6">Article Title</a></h2>
														<a href="previous-works.php#article5-6"><p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Earum temporibus eum, nihil quidem perferendis, culpa maiores reiciendis quo porro in, minus delectus error facilis molestiae omnis nobis tempore. Impedit, et?</p> </a>
														</div>
													</div>
												</div>
											</article>
											<!-- ARTICLE : end -->

											<!-- ARTICLE : begin -->
											<article class="c-article m-cropped">
												<div class="article-inner">
													<div class="article-image">
														<a href="previous-works.php#article5-6"><img src="images/article-01-th.jpg" alt=""></a>
													</div>
													<div class="article-content">
														<div class="content-inner">
															<h2 class="article-title"><a href="previous-works.php#article5-6">Article Title</a></h2>
														<a href="previous-works.php#article5-6"><p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Earum temporibus eum, nihil quidem perferendis, culpa maiores reiciendis quo porro in, minus delectus error facilis molestiae omnis nobis tempore. Impedit, et?</p> </a>
														</div>
													</div>
												</div>
											</article>
											<!-- ARTICLE : end -->

										</div>
										<!-- ARTICLE LIST : end -->

									</div>
								</div>
								<!-- CAROUSEL : end -->

							</div>
						</div>
					</section>
					<!-- ARTICLES SECTION : end -->

				</div>
				<!-- PAGE CONTENT : end -->

			</div>
			<!-- CORE : end -->

			<!-- FOOTER : begin -->
			<div id="footer" class="m-parallax">

				<!-- FOOTER INNER : begin -->
				<div class="footer-inner">
					<div class="container">

						<!-- BOTTOM PANEL : begin -->
						<div id="bottom-panel">
							<div class="row">
								<div class="col-md-4">

									<!-- TEXT WIDGET : begin -->
									<div class="widget text-widget">
										<div class="widget-inner">
											<h3 class="widget-title"><strong>Rólam</strong></h3>
											<div class="widget-content">

												<p><strong>Vác Villanyszerelés</strong> <br>
												<strong>Elektronikai eszközök</strong> javítása, <strong>lámpák</strong> beszerelése, hálózat <strong>kiépítés,</strong> és <strong>újjáépítés.</strong></p>

											</div>
										</div>
									</div>
									<!-- TEXT WIDGET : end -->

									<hr class="c-divider hidden-lg hidden-md">

								</div>
								<div class="col-md-4">

									<!-- TEXT WIDGET (CONTACT) : begin -->
									<div class="widget text-widget">
										<div class="widget-inner">
											<h3 class="widget-title"><strong>Elérhetőségek</strong></h3>
											<div class="widget-content">

												<p>Telefon: <strong>(123) 456 789</strong>
													<br> Elérhetőség: <strong>Hétköznap 10:00-18:00</strong>
												<br>
												</p>

											</div>
										</div>
									</div>
									<!-- TEXT WIDGET (CONTACT) : end -->

									<hr class="c-divider hidden-lg hidden-md">

								</div>
								<div class="col-md-4">

									<!-- SUBSCRIBE WIDGET : begin -->
									<div class="widget subscribe-widget">
										<div class="widget-inner">
											<h3 class="widget-title">Írj nekem <strong>Emailt </strong>bármikor:</h3>
											<div class="widget-content">

													Lépj velem kapcsolatba:
													<strong><a href="mailto:PLACEHOLDER.EMAIL.COM">PLACEHOLDER.EMAIL.COM</a></strong>
													<br>
													<br>
													<!-- EZ EGY MÁSIK FUNKCIÓ IDE MAJD EGY OLYAN EMAIL KÉNE AMI ÁT VISZ A CONTACT FORMBA
														PL: BEÍROD AZ EMAIL CÍMEDET ÉS A KÜLDÉSGOMBRA KATTINTA ÁTVISZ A CONTACT.php-RE ÉS BEÍRJA AZT AZ
														EMAILT AMIT A FELHASZNÁLÓ MEGADOTT, KÉSÖBB, VAGY LEHET NEM IS KELL
												<form class="subscribe-widget-form" action="http://lsvr.us14.list-manage.com/subscribe/post-json?u=8291218baaf54ddfd7dbc6016&id=f3e5d696dc&c=?" method="get">

													 VALIDATION ERROR MESSAGE : begin 
													<p style="display: none;" class="c-alert-message m-warning m-validation-error"><i class="ico fa fa-exclamation-circle"></i>Email address is required.</p>
													<!-- VALIDATION ERROR MESSAGE : end 

													<!-- SENDING REQUEST ERROR MESSAGE : begin 
													<p style="display: none;" class="c-alert-message m-warning m-request-error"><i class="ico fa fa-exclamation-circle"></i>There was a connection problem. Try again later.</p>
													<!-- SENDING REQUEST ERROR MESSAGE : end 

													<!-- SUCCESS MESSAGE : begin 
													<p style="display: none;" class="c-alert-message m-success"><i class="ico fa fa-check-circle"></i><strong>Sent successfully.</strong></p>
													<!-- SUCCESS MESSAGE : end 

													<div class="input-box">
														<input class="email-input m-required m-email" name="EMAIL" type="text" placeholder="Your email address here" title="Your email address here">
														<button class="submit-btn" type="submit" title="Subscribe"><i class="fa fa-chevron-right"></i></button>
													</div>

												</form>
											-->
											</div>
										</div>
									</div>
									<!-- SUBSCRIBE WIDGET : end -->

								</div>
							</div>
						</div>
						<!-- BOTTOM PANEL : end -->

						<div class="row">
							<div class="col-md-6 col-md-push-6">

							</div>
							<div class="col-md-6 col-md-pull-6">


							</div>
						</div>

					</div>
				</div>
				<!-- FOOTER INNER : end -->

			</div>
			<!-- FOOTER : end -->

		</div>
		<!-- WRAPPER : END -->

		<!-- SCRIPTS : begin -->
		<script src="library/js/jquery-1.9.1.min.js" type="text/javascript"></script>
		<script src="library/js/third-party.js" type="text/javascript"></script>
		<script src="library/js/library.js" type="text/javascript"></script>
		<script src="library/js/scripts.js" type="text/javascript"></script>
		<!-- SCRIPTS : end -->

	</body>
</html>