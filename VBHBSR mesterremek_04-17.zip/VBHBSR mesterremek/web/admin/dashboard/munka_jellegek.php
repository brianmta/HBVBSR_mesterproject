<?php
    require_once('header.php');
    require_once('functions/func_munka_jell_listaz.php');
    require_once('functions/func_munka_jelleg_uj.php');
    $munka_jelleg = munka_jell_lekerdez();

    if (isset($_POST['ment'])){
        munka_jell_felvitel(); 
    }
?>
<center>
	<div class="container mt-3">
		<div class="row">
			<div class="col-sm-12">
				<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
					<input type="hidden" name="id" value="<?php echo $id; ?>">
					<div class="col-sm-6">
						<legend align="center" style="text-transform: uppercase; background-color:lavender;">Munka jellegek</legend>
						<br><br>
						<div class="form-group">
							<label for="munka_jell">Új munka jelleg megnevezése:</label>
							<input type="text" class="form-control width" name="munka_jell" id="munka_jell" placeholder="pl.: légkondícionáló szerelés" maxlength="25" required>
						</div>
						<br>
						<input type="submit" name="ment" value="Hozzáad" class="btn btn-success mt-3">
						<br><br>
						
<style>
	hr.dashed {
		border-top: 3px solid black;
	}
    .text-centered{
        text-align: center;
    }
	.width {
		width: 250px;
	}
</style>

						<hr class="dashed">
						<br>	
						<table class="table table-hover table-sm table-bordered">
							<thead>
								<th><Center>ID</center></th>
								<th><Center>Megnevezés</center></th>
								<th colspan="2"><Center>Műveletek</center></th>
							</thead>
							<tbody class="text-centered">
<?php
    foreach ($munka_jelleg as $munka_jell){
        echo "<tr>";
        echo "<td>". $munka_jell['id']. "</td>";
        echo "<td>". $munka_jell['megnevezes']. "</td>";
        echo "<td>". '<a class="btn btn-warning" href="munka_jell_modosit.php?id='. $munka_jell['id'].'"> ✎ </a> '. "</td>";
        echo "<td>". '<a class="btn btn-danger" href="munka_jell_torol.php?id='. $munka_jell['id'].'"> 🗑 </a>'. "</td>"; 
    }
?>
							</tbody>
						</table>
					</div>
				</form>
			</div>
		</div>
	</div>
</center>

</div>
</div>
</body>
</html>