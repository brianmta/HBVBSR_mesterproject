<?php
    require_once('db_connect.php');

    function munka_jell_lekerdez_id_alapjan($id){
        $mysqli = db_connect();
        $sql = "SELECT * FROM `munka_jell` WHERE `id` = '$id'";
        $eredmeny = $mysqli->query($sql);
        $munka_jell = mysqli_fetch_assoc($eredmeny);
        return $munka_jell;
    }

    function munka_jell_modosit(){
        $mysqli = db_connect();
        $id = $_POST['id'];
        $munka_jell_id = $_POST['munka_jell'];
        $sql = "UPDATE `munka_jell` SET `megnevezes` = '$munka_jell_id' WHERE `id`='$id'";;
        $eredmeny = $mysqli->query($sql);
        if ($eredmeny){
            $url = "munka_jellegek.php";
            header('Location: ' . $url);
        } else {
            echo $mysqli->error;
        }
        mysqli_close($mysqli);
    }
?>