<?php
    require_once('db_connect.php');

    function varos_lekerdez_id_alapjan($id){
        $mysqli = db_connect();
        $sql = "SELECT * FROM `varosok` WHERE `id` = '$id'";
        $eredmeny = $mysqli->query($sql);
        $varos = mysqli_fetch_assoc($eredmeny);
        return $varos;
    }

    function varos_modosit(){
        $mysqli = db_connect();
        $id = $_POST['id'];
        $iranyitoszam = $_POST['iranyitoszam'];
        $varos = $_POST['varos'];
        $sql = "UPDATE `varosok` SET `iranyitoszam` = '$iranyitoszam', `varos` = '$varos' WHERE `id`='$id'";;
        $eredmeny = $mysqli->query($sql);
        if ($eredmeny){
            $url = "varosok.php";
            header('Location: ' . $url);
        } else {
            echo $mysqli->error;
        }
        mysqli_close($mysqli);
    }
?>