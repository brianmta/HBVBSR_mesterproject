<?php
    require_once('header.php');
    require_once('functions/func_megrendelesek_listaz.php');
    require_once('functions/func_sort_by_order_date.php');
    $megrendelesek = megrendelesek_lekerdez();
    $megrendelesek = megrendelesek_sort_by_order_date();   
?>
<div class="container mt-3">
	<div class="table-responsive-lg">
		<legend style="text-transform: uppercase; background-color:lavender;"><center> Megrendelések </center></legend>
		<br><br>
		<table class="table table-hover table-sm">
			<thead>
				<th><Center>ID</center></th>
				<th><Center>Megrend. ⬍</center></th>
				<th><Center>Kezdés</center></th>
				<th><Center>Név</center></th>
				<th><Center>Város</center></th>
				<th><Center>Cím</center></th>
				<th><Center>Email</center></th>
				<th><Center>Telefon</center></th>
				<th><Center>Munka jell.</center></th>
				<th><Center>Státusz</center></th>
				<th colspan="4"><Center>Műveletek</center></th>
			</thead>
        <tbody class="text-centered">
		
<style>
    .text-centered{
        text-align: center;
    }
</style>

<?php
	foreach ($megrendelesek as $megrendeles){
    echo "<tr>";
    echo "<td>". $megrendeles['id']. "</td>";
    echo "<td>". $megrendeles['megrend_datum']. "</td>";
    echo "<td>". $megrendeles['kezdodatum']. "</td>";
    echo "<td>". $megrendeles['ugyfel_nev']. "</td>";
    echo "<td>". $megrendeles['varos']. "</td>";
    echo "<td>". $megrendeles['ugyfel_cim']. "</td>";
    echo "<td>". $megrendeles['ugyfel_email']."</td>";
    echo "<td>". $megrendeles['ugyfel_tel']. "</td>";
    echo "<td>". $megrendeles['munka_jelleg']. "</td>";
    echo "<td>". $megrendeles['statusz']. "</td>";
    "<td>". $megrendeles['uzenet']. "</td>";
    echo "<td>";
?>
			
<style>
.tooltip-text {
  visibility: hidden;
  position: absolute;
  z-index: 1;
  width: max-content;
  max-width: 250px;
  color: white;
  font-size: 18px;
  text-align: center;
  background-color: #192733;
  border-radius: 10px;
  padding: 10px 15px 10px 15px;
}

.hover-text:hover .tooltip-text {
  visibility: visible;
}

#left {
  top: -8px;
  right: 120%;
}


.hover-text {
  position: relative;
  display: block;
  font-family: Arial;
  text-align: center;
}

html, body {
    max-width: 100%;
    overflow-x: hidden;
}
</style>
					
		<div class="hover-text btn btn-info">💬
			<span class="tooltip-text" id="left"> <?php echo $megrendeles['uzenet'] ?></span>
		</div>
<?php
    echo "<td>". '<a class="btn btn-warning" href="megrendeles_modosit.php?id='. $megrendeles['id'].'"> ✎ </a> '. "</td>";
	echo "<td>". '<a class="btn btn-danger" href="megrendeles_torol.php?id='. $megrendeles['id'].'"> 🗑 </a>'. "</td>";     
    echo "</tr>";
    }
?>
        </tbody>   
		</table>
	<br>
    </div>
</div>
</div>      
</div>
</body>
</html>


