<?php
    require_once('dashboard/functions/db_connect.php');
    session_start();

    if (isset($_POST['login']) && !empty($_POST['userName']) && !empty($_POST['password'])){
        $userName =  mysqli_real_escape_string($mysqli, $_POST['userName']);
        $password =  mysqli_real_escape_string($mysqli, sha1($_POST['password']));

        $sql = "SELECT * FROM admin WHERE user LIKE '$userName' AND jelszo LIKE '$password';";
        $result = $mysqli->query($sql);

        if (mysqli_num_rows($result) == 1){
            $userData = mysqli_fetch_array($result);
            $userId = $userData['id'];
            $userName = $userData['user'];
            mysqli_close($mysqli);  

            $_SESSION['userId'] = $userId;
            $_SESSION['userName'] = $userName;

            $url = 'dashboard/index.php';
            header("Location: ".$url);          
        } else {
            mysqli_close($mysqli);
            $errorMessage = "Hibás felhasználónév/jelszó!";
        }
    }
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adminisztrációs felület</title>
    <link rel="shortcut icon" href="../../images/logo.2x.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
</head>

<style>
	html, body {
		max-width: 100%;
		overflow-x: hidden;
	}
</style>

<body>
    <div class="row">
        <div class="jumbotron bg-info text-white pt-3 pb-3">
            <h1 class="display3 text-center"><b>Bejelentkezés</b></h1>
            <h5 class="display3 text-center">Vác Villanyszerelés</h5>
        </div>
    </div>    
    <div class="container mt-5 d-flex justify-content-center">
        <div class="col-sm-2">
            <form action="<?php $_SERVER['PHP_SELF'];?>" method="POST">
                <div class="form-group">
                    <label for="userName">Felhasználónév*</label>
                    <input type="text" class="form-control" name="userName" id="userName" required>
                </div> 
                <br>
                <div class="form-group">    
                    <label for="password">Jelszó*</label>
                    <input type="password" class="form-control" name="password" id="password" required>
                </div>
                <div class="form-group">  <br>  
					<center><input type="submit" class="btn btn-success mt-3" name="login" id="login" value="Belépés"></center>
                </div>
                <br>
                <center><span class="text-danger"><?php isset($errorMessage) ? print $errorMessage : print ""; ?></span></center>
            </form>
        </div>
    </div>
</body>
</html>