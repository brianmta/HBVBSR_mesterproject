<?php
	error_reporting(0);
	session_start();
    require_once('db_connect.php');
	
	if (isset($_POST['contact_name'], $_POST['contact_email'], $_POST['contact_phone'], $_POST['contact_city'], $_POST['contact_job'], $_POST['contact_address'], $_POST['contact_message']))
	{
		insert();
	}
	
    function insert(){
        $mysqli = db_connect();
        $contact_name = $_POST['contact_name'];
        $contact_email = $_POST['contact_email'];
        $contact_phone = $_POST['contact_phone'];
        $contact_city = $_POST['contact_city'];
        $contact_job = $_POST['contact_job'];
        $contact_address = $_POST['contact_address'];
        $contact_message = $_POST['contact_message'];
        		
		$stmt = $mysqli->prepare("INSERT INTO megrendelesek (megrend_datum,ugyfel_nev,varos_id, ugyfel_cim, ugyfel_email, ugyfel_tel, munka_jell_id, uzenet, statusz_id) 
	    VALUES (NOW(), ?, ?, ?, ?, ?, ?, ?, '1')");
		$stmt->bind_param("sisssis", $contact_name, $contact_city, $contact_address, $contact_email, $contact_phone, $contact_job, $contact_message);
		$eredmeny = $stmt->execute();
    
		$success_text = "Megrendel�s sikeresen leadva! Hamarosan �rtes�teni fogom a megadott el�rhet�s�gek egyik�n.";
        if ($eredmeny) {
			$_SESSION['info']=utf8_encode($success_text);
			header("Location: ../contact.php");
        } else {
			echo $mysqli->error;
		}
        mysqli_close($mysqli);
    }
?>