<?php
    require_once('db_connect.php');

    function munka_jell_felvitel(){
        $mysqli = db_connect();
        $munka_jell = $_POST['munka_jell'];
        $sql = "INSERT INTO munka_jell (megnevezes) VALUES ('$munka_jell')";
        $eredmeny = $mysqli->query($sql);
    
        if ($eredmeny) {
            $url = './munka_jellegek.php';
            header('Location: ' . $url);
            } else {   
                echo $mysqli->error;
        } 
        mysqli_close($mysqli);
    }
?>