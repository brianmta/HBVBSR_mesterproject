<?php
    require_once('db_connect.php');

    function statusz_felvitel(){
        $mysqli = db_connect();
        $statusz = $_POST['statusz'];
        $sql = "INSERT INTO statuszok (megnevezes) VALUES ('$statusz')";
        $eredmeny = $mysqli->query($sql);
    
        if ($eredmeny) {
            $url = './index.php';
            header('Location: ' . $url);
            } else {   
                echo $mysqli->error;
        } 
        mysqli_close($mysqli);
    }
?>