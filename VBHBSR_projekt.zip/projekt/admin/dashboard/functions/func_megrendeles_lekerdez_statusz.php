<?php
    require_once('db_connect.php');

    function statusz_kategoriak_lekerdez(){
        $mysqli = db_connect();
        $sql = "SELECT * FROM statuszok";
        $eredmeny = $mysqli->query($sql);
        if ($eredmeny){
            while ($sor = mysqli_fetch_assoc($eredmeny)){
                $statusz_kategoriak[] = $sor;
            }
        } else {
            die("SQL hiba: ".$mysqli->error);
        }
        mysqli_close($mysqli);
    return $statusz_kategoriak;
    }
?>