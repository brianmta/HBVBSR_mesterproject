<?php
    require_once('db_connect.php');

    function megrendelesek_lekerdez(){
        $mysqli = db_connect();
        $sql = "SELECT m.id, m.megrend_datum, m.kezdodatum, m.ugyfel_nev, v.varos, m.ugyfel_cim, m.ugyfel_email, m.ugyfel_tel, mu.megnevezes AS munka_jelleg, m.uzenet, s.megnevezes AS statusz
        FROM megrendelesek AS m
        INNER JOIN varosok AS v ON v.id = m.varos_id
        INNER JOIN munka_jell AS mu ON mu.id = m.munka_jell_id
        INNER JOIN statuszok AS s ON s.id = m.statusz_id;";
        $eredmeny = $mysqli->query($sql);
        if ($eredmeny){
            while ($sor = mysqli_fetch_assoc($eredmeny)){
                $megrendelesek[] = $sor;
            }
        } else {
            die("SQL hiba: ".$mysqli->error);
        }
        mysqli_close($mysqli);
    return $megrendelesek;
    }
?>