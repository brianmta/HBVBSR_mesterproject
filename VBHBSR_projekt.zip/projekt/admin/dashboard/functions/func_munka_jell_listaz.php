<?php
    require_once('db_connect.php');

    function munka_jell_lekerdez(){
        $mysqli = db_connect();
        $sql = "SELECT id, megnevezes FROM munka_jell;"; 
        $eredmeny = $mysqli->query($sql);
        if ($eredmeny){
            while ($sor = mysqli_fetch_assoc($eredmeny)){
                $munka_jell[] = $sor;
            }
        } else {
            die("SQL hiba: ".$mysqli->error);
        }
        mysqli_close($mysqli);
    return $munka_jell;
    }
?>