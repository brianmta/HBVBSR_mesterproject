<?php
    require_once('db_connect.php');

    function megrendeles_felvitel(){
        $mysqli = db_connect();
        $megrend_datum = $_POST['megrend_datum'];
        $kezdodatum = $_POST['kezdodatum'];
        $ugyfel_nev = $_POST['ugyfel_nev'];
        $varos_id = $_POST['varos_id'];
        $ugyfel_cim = $_POST['ugyfel_cim'];
        $ugyfel_email = $_POST['ugyfel_email'];
        $ugyfel_tel = $_POST['ugyfel_tel'];
        $munka_jell_id = $_POST['munka_jell_id'];
        $uzenet = trim($_POST['uzenet']);
        $statusz_id = $_POST['statusz_id'];
        $sql = "INSERT INTO megrendelesek (megrend_datum,kezdodatum,ugyfel_nev,varos_id,ugyfel_cim, ugyfel_email, ugyfel_tel, 
        munka_jell_id, uzenet, statusz_id) VALUES ('$megrend_datum','$kezdodatum','$ugyfel_nev','$varos_id','$ugyfel_cim',
        '$ugyfel_email','$ugyfel_tel','$munka_jell_id','$uzenet','$statusz_id')";
        $eredmeny = $mysqli->query($sql);
    
        if ($eredmeny) {
            $url = './index.php';
            header('Location: ' . $url);
            } else {   
                echo $mysqli->error;
        } 
        mysqli_close($mysqli);
    }
?>