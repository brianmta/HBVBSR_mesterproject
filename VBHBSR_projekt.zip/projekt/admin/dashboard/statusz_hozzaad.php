<?php
    require_once('header.php');
    require_once('functions/func_statusz_uj.php');

    if (isset($_POST['ment'])){
        statusz_felvitel(); 
    }
?>
<div class="container mt-3">
    <div class="row">
        <div class="col-sm-12">
			<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="statusz">Új munka státusz hozzáadása: </label>
                        <input type="text" class="form-control" name="statusz" id="statusz" placeholder="PL.:Elutasítva" required>
                    </div> 
                    <a href="javascript:history.back()" class="btn btn-warning mt-3">Mégsem</a> 
                    <input type="submit" name="ment" value="Új munka státusz hozzáadása" class="btn btn-success mt-3">
                </div>
			</form> 
        </div>
	</div>
</div>

</div>
</div>
</body>
</html>