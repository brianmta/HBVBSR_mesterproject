<?php
    require_once('header.php');
    require_once('functions/func_munka_jell_modosit.php');
 
    if (isset($_GET['id'])){
        $id = $_GET['id'];
        $munka_jell = munka_jell_lekerdez_id_alapjan($id);
    }

    if (isset($_POST['modosit'])){
        munka_jell_modosit(); 
    }
?>
<center>
<div class="container mt-3">
    <div class="row">
        <div class="col-sm-12">
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <div class="col-sm-6">
                    <div class="form-group width">
                        <label for="munka_jell">Megnevezés:</label>
                        <input type="text" class="form-control" name="munka_jell" id="munka_jell" placeholder="pl.: légkondícionáló szerelés" value="<?php echo $munka_jell['megnevezes']; ?>" required>
                    </div>
                </div> 
				<br>
                <a href="javascript:history.back()" class="btn btn-warning mt-3">Mégsem</a> 
                <input type="submit" name="modosit" value="Módosít" class="btn btn-success mt-3"> 
            </form>
        </div> 
    </div> 
</div>
</center>

<style>
	.width {
		width: 250px;
	}
</style>

</div>
</div>
</body>
</html>