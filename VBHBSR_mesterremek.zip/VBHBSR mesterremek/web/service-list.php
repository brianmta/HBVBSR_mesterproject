﻿<?php
error_reporting(0);
?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Vác Villanyszerelés</title>
        <link rel="shortcut icon" href="images/logo.2x.png">

		<!-- GOOGLE FONTS : begin -->
		<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic%7cExo+2:400,700&amp;subset=latin,latin-ext" rel="stylesheet" type="text/css">
		<!-- GOOGLE FONTS : end -->

        <!-- STYLESHEETS : begin -->
		<link rel="stylesheet" type="text/css" href="library/css/style.css">
        <link rel="stylesheet" type="text/css" href="library/css/skin/default.css">
		<link rel="stylesheet" type="text/css" href="library/css/custom.css">
		<!-- STYLESHEETS : end -->

		<script src="library/js/modernizr.custom.min.js" type="text/javascript"></script>

	</head>
	<body class="m-fixed-header">

		<!-- WRAPPER : begin -->
		<div id="wrapper">

						<!-- HEADER : begin -->
						<header id="header">
							<div class="header-inner">
								<div class="container">
			
									<!-- HEADER BRANDING : begin -->
									<div class="header-branding">
										<div class="branding-inner">
			
											<!-- BRANDING LOGO : begin -->
											<div class="brading-logo">
												<a href="index.php"><img src="images/logo.png" data-hires="images/logo.2x.png" alt="Blue Collar"></a>
											</div>
											<!-- BRANDING LOGO : end -->
			
											<!-- BRANDING INFO : begin -->
											<div class="brading-info">
												<strong>Vollai Attila</strong><br>
												<em>Vác Villanyszerelés</em>
											</div>
											<!-- BRANDING INFO : end -->
			
										</div>
									</div>
									<!-- HEADER BRANDING : end -->
			
									<!-- NAVIGATION TOGGLE : begin -->
									<button class="header-navigation-toggle" type="button"><i class="fa fa-bars"></i></button>
									<!-- NAVIGATION TOGGLE : end -->
			
									<!-- HEADER NAVIGATION : begin -->
									<div class="header-navigation">
										<div class="navigation-inner">
			
											<!-- HEADER MENU : begin -->
											<nav class="header-menu">
												<ul>
													<li>
														<a href="index.php">Főoldal</a>
													</li>
													<li class="m-active">
														<a href="service-list.php">Szolgáltatások</a>
														<ul>
															<li><a href="service-detail.php">További információ</a></li>
														</ul>
													</li>
													<li>
														<a href="portfolio.php">Rólam</a>
														<ul>
															<li><a href="previous-works.php">Korábbi munkáim</a></li>
														</ul>
													</li>
													<li><a href="contact.php">Kapcsolat</a></li>
												</ul>
											</nav>
											<!-- HEADER MENU : end -->
			
										</div>
									</div>
									<!-- HEADER NAVIGATION : end -->
			
								</div>
							</div>
						</header>
						<!-- HEADER : end -->

			<!-- CORE : begin -->
			<div id="core">

				<!-- PAGE TITLE : begin -->
				<div id="page-title" class="m-parallax">

					<!-- PAGE TITLE TOP : begin -->
					<div class="page-title-top">
						<div class="page-title-top-inner">

							<!-- PAGE TITLE TEXT : begin -->
							<div class="page-title-text">
								<div class="container">
									<h1>Szolgáltatások</h1>
								</div>
							</div>
							<!-- PAGE TITLE TEXT : end -->

						</div>
					</div>
					<!-- PAGE TITLE TOP : end -->

					<!-- PAGE TITLE BOTTOM : begin -->
					<div class="page-title-bottom">
						<div class="container">
							<div class="page-title-bottom-inner">
								<div class="page-title-bottom-inner2">

									<!-- PAGE TITLE BREADCRUMBS : begin -->
									<div class="page-title-breadcrumbs">
										<ul>
											<li><a href="index.php">Főoldal</a></li>
											<li>Szolgáltatások</li>
										</ul>
									</div>
									<!-- PAGE TITLE BREADCRUMBS : end -->

								</div>
							</div>
						</div>
					</div>
					<!-- PAGE TITLE BOTTOM : end -->

				</div>
				<!-- PAGE TITLE : end -->

				<div class="container">

					<!-- PAGE CONTENT : begin -->
					<div id="page-content">

						<h2>Miben tudok segíteni?</h2>

						<!-- SERVICE LIST : begin -->
						<ul class="c-service-list m-4-per-row">

							<!-- SERVICE : begin -->
							<li class="c-service">
								<div class="service-inner">

									<div class="service-title" style="background-image: url( 'images/electricalSystemCopy.jpg' );">
										<div><div><div>
											<span class="service-icon"><i class="im im-switch"></i></span>
											<h3 class="service-white">Elektromos hálózatok</h3>
										</div></div></div>
									</div>
									<div class="service-description">
										<div>
										<br>
										<hr class="c-divider m-size-small">
										<center><p><a href="service-detail.php#networks">Több információ az <br><strong>Elektromos hálózatokkal </strong><br> kapcsolatban</a></p></center>
										</div>
									</div>

								</div>
							</li>
							<!-- SERVICE : end -->

							<!-- SERVICE : begin -->
							<li class="c-service">
								<div class="service-inner">

									<div class="service-title" style="background-image: url( 'images/electricalSystemCopy.jpg' );">
										<div><div><div>
											<span class="service-icon"><i class="im im-handdrill"></i></span>
											<h3 class="service-white">Elektronikai eszközök</h3>
										</div></div></div>
									</div>
									<div class="service-description">
										<div>
										<br>
										<hr class="c-divider m-size-small">
										<center><p><a href="service-detail.php#electricalAppliances">Több információ az <br><strong>Elektromos eszközökkel </strong><br> kapcsolatban</a></p></center>
										</div>
									</div>

								</div>
							</li>
							<!-- SERVICE : end -->

							<!-- SERVICE : begin -->
							<li class="c-service">
								<div class="service-inner">

									<div class="service-title" style="background-image: url( 'images/electricalSystemCopy.jpg' );">
										<div><div><div>
											<span class="service-icon"><i class="im im-wrench-screwdriver"></i></span>
											<h3 class="service-white">Karbantartás, kiújítás</h3>
										</div></div></div>
									</div>
									<div class="service-description">
										<div><div>
										<br>
										<hr class="c-divider m-size-small">
										<center><p><a href="service-detail.php#maintenence">Több információ a <br> <strong>Karbantartással</strong><br> kapcsolatban</a></p></center>
										</div></div>
									</div>

								</div>
							</li>
							<!-- SERVICE : end -->

							<!-- SERVICE : begin -->
							<li class="c-service">
								<div class="service-inner">

									<div class="service-title" style="background-image: url( 'images/electricalSystemCopy.jpg' );">
										<div><div><div>
											<span class="service-icon"><i class="im im-lightning-bolt"></i></span>
											<h3 class="service-white">Felmérés, tanácsadás</h3>
										</div></div></div>
									</div>
									<div class="service-description">
										<div>
										<br>
										<hr class="c-divider m-size-small">
										<center><p><a href="service-detail.php#surveying">Több információ a <br> <strong>Felmérésekkel</strong><br> kapcsolatban</a></p></center>
										</div>
									</div>

								</div>
							</li>
							<!-- SERVICE : end -->

						</ul>
						<!-- SERVICE LIST : end -->

					</div>
					<!-- PAGE CONTENT : end -->

				</div>

			</div>
			<!-- CORE : end -->

			<!-- FOOTER : begin -->
			<div id="footer" class="m-parallax">

				<!-- FOOTER INNER : begin -->
				<div class="footer-inner">
					<div class="container">

						<!-- BOTTOM PANEL : begin -->
						<div id="bottom-panel">
							<div class="row">
								<div class="col-md-4">

									<!-- TEXT WIDGET : begin -->
									<div class="widget text-widget">
										<div class="widget-inner">
											<h3 class="widget-title"><strong>Rólam</strong></h3>
											<div class="widget-content">
												<p><strong>Vác Villanyszerelés</strong> <br>
												<strong>Elektronikai eszközök</strong> javítása, <strong>lámpák</strong> beszerelése, hálózat <strong>kiépítés,</strong> és <strong>újjáépítés.</strong></p>
											</div>
										</div>
									</div>
									<!-- TEXT WIDGET : end -->

									<hr class="c-divider hidden-lg hidden-md">

								</div>
								<div class="col-md-4">

									<!-- TEXT WIDGET (CONTACT) : begin -->
									<div class="widget text-widget">
										<div class="widget-inner">
											<h3 class="widget-title"><strong>Elérhetőségek</strong></h3>
											<div class="widget-content">
												<p>
												Telefon: <strong>+36 30 283 7830</strong>
												<br> 
												Elérhetőség: <strong>Hétköznap 09:00-16:00</strong>
												<br>
												</p>
											</div>
										</div>
									</div>
									<!-- TEXT WIDGET (CONTACT) : end -->

									<hr class="c-divider hidden-lg hidden-md">

								</div>
								<div class="col-md-4">

									<!-- SUBSCRIBE WIDGET : begin -->
									<div class="widget subscribe-widget">
										<div class="widget-inner">
											<h3 class="widget-title">Írjon <strong>Emailt </strong>bármikor:</h3>
											<div class="widget-content">

													Lépj velem kapcsolatba:
													<strong><a href="mailto:vollai.attila.villanyszereles@gmail.com">vollai.attila.villanyszereles@gmail.com</a></strong>
													<br>
													<br>
											</div>
										</div>
									</div>
									<!-- SUBSCRIBE WIDGET : end -->
									
								</div>
							</div>
						</div>
						<!-- BOTTOM PANEL : end -->

						<div class="row">
							<div class="col-md-6 col-md-push-6">
							</div>
							<div class="col-md-6 col-md-pull-6">
							</div>
						</div>

					</div>
				</div>
				<!-- FOOTER INNER : end -->

			</div>
			<!-- FOOTER : end -->

		</div>
		<!-- WRAPPER : END -->

		<!-- SCRIPTS : begin -->
		<script src="library/js/jquery-1.9.1.min.js" type="text/javascript"></script>
		<script src="library/js/third-party.js" type="text/javascript"></script>
		<script src="library/js/library.js" type="text/javascript"></script>
		<script src="library/js/scripts.js" type="text/javascript"></script>
		<!-- SCRIPTS : end -->

	</body>
</html>