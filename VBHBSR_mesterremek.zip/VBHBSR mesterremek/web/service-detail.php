﻿<?php
error_reporting(0);
?>
<!DOCTYPE html>
<html>
	<head>

		<meta http-equiv="content-type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Vác Villanyszerelés</title>
        <link rel="shortcut icon" href="images/logo.2x.png">

		<!-- GOOGLE FONTS : begin -->
		<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic%7cExo+2:400,700&amp;subset=latin,latin-ext" rel="stylesheet" type="text/css">
		<!-- GOOGLE FONTS : end -->

        <!-- STYLESHEETS : begin -->
		<link rel="stylesheet" type="text/css" href="library/css/style.css">
        <link rel="stylesheet" type="text/css" href="library/css/skin/default.css">
		<link rel="stylesheet" type="text/css" href="library/css/custom.css">
		
		<!-- STYLESHEETS : end -->

		<script src="library/js/modernizr.custom.min.js" type="text/javascript"></script>

	</head>
	<body class="m-fixed-header">

		<!-- WRAPPER : begin -->
		<div id="wrapper">

						<!-- HEADER : begin -->
						<header id="header">
							<div class="header-inner">
								<div class="container">
			
									<!-- HEADER BRANDING : begin -->
									<div class="header-branding">
										<div class="branding-inner">
			
											<!-- BRANDING LOGO : begin -->
											<div class="brading-logo">
												<a href="index.php"><img src="images/logo.png" data-hires="images/logo.2x.png" alt="Blue Collar"></a>
											</div>
											<!-- BRANDING LOGO : end -->
			
											<!-- BRANDING INFO : begin -->
											<div class="brading-info">
												<strong>Vollai Attila</strong><br>
												<em>Vác Villanyszerelés</em>
											</div>
											<!-- BRANDING INFO : end -->
			
										</div>
									</div>
									<!-- HEADER BRANDING : end -->
			
									<!-- NAVIGATION TOGGLE : begin -->
									<button class="header-navigation-toggle" type="button"><i class="fa fa-bars"></i></button>
									<!-- NAVIGATION TOGGLE : end -->
			
									<!-- HEADER NAVIGATION : begin -->
									<div class="header-navigation">
										<div class="navigation-inner">
			
											<!-- HEADER MENU : begin -->
											<nav class="header-menu">
												<ul>
													<li>
														<a href="index.php">Főoldal</a>
													</li>
													<li class="m-active">
														<a href="service-list.php">Szolgáltatások</a>
														<ul>
															<li><a href="service-detail.php">További információ</a></li>
														</ul>
													</li>
													<li>
														<a href="portfolio.php">Rólam</a>
														<ul>
															<li><a href="previous-works.php">Korábbi munkáim</a></li>
														</ul>
													</li>
													<li><a href="contact.php">Kapcsolat</a></li>
												</ul>
											</nav>
											<!-- HEADER MENU : end -->
			
										</div>
									</div>
									<!-- HEADER NAVIGATION : end -->
			
								</div>
							</div>
						</header>
						<!-- HEADER : end -->

			<!-- CORE : begin -->
			<div id="core">

				<!-- PAGE TITLE : begin -->
				<div id="page-title" class="m-parallax">

					<!-- PAGE TITLE TOP : begin -->
					<div class="page-title-top">
						<div class="page-title-top-inner">

							<!-- PAGE TITLE TEXT : begin -->
							<div class="page-title-text">
								<div class="container">
									<h1>További információ</h1>
								</div>
							</div>
							<!-- PAGE TITLE TEXT : end -->

						</div>
					</div>
					<!-- PAGE TITLE TOP : end -->

					<!-- PAGE TITLE BOTTOM : begin -->
					<div class="page-title-bottom">
						<div class="container">
							<div class="page-title-bottom-inner">
								<div class="page-title-bottom-inner2">

									<!-- PAGE TITLE BREADCRUMBS : begin -->
									<div class="page-title-breadcrumbs">
										<ul>
											<li><a href="index.php">Főoldal</a></li>
											<li><a href="service-list.php">Szolgáltatások</a></li>
											<li>További információ</li> 							<a id="networks"> </a>
										</ul>
									</div>
									<!-- PAGE TITLE BREADCRUMBS : end -->

								</div>
							</div>
						</div>
					</div>
					<!-- PAGE TITLE BOTTOM : end -->

				</div>
				<!-- PAGE TITLE : end -->

				<div class="container">
					<div class="row">
						<div class="col-md-9 col-md-push-3">
							<!-- PAGE CONTENT ELETRIC NETWORK: begin -->
							<div id="page-content">

								<h2>Elektromos Hálózatok</h2>

								<div class="row">
									<div class="col-md-6">

										<dl>
											<dt>Épületvillamossági és erősáramú villanyszerelés</dt>
											<br>
											<dd><p align="justify">Az épületvillamossági és erősáramú villanyszerelés az épületekben használt elektromos rendszerek tervezése, telepítése, karbantartása és javítása.
											Az épületvillamossági rendszerek magukba foglalják az elektromos kábelezést, az elosztópaneleket, a világítási rendszereket, a konnektorokat és a kapcsolókat,
											valamint más elektromos berendezéseket, amelyeket az épületen belül használnak. 
											Az erősáramú villanyszerelés pedig olyan rendszereket foglal magában, amelyek nagyfeszültségű áramot szállítanak, például az ipari gyártósorokban
											és az erőművekben használt elektromos berendezéseket. Az épületvillamossági és erősáramú villanyszerelés fontos szerepet játszik az épületek biztonságos és hatékony működésében.</dd>
											<dt>Villamos hálózatok</dt>
											<br>
											<dd><p align="justify">Ezek a munkálatok magukban foglalhatják az elektromos vezetékek és kábelek telepítését, 
											az elosztórendszerek kialakítását, más elektromos berendezések telepítését és karbantartását.</dd>
										</dl>
									</div>
									<div class="col-md-6">
										<dl>
											<dt>Ipari villanyszerelés</dt>
											<br>
											<dd><p align="justify">Az ipari villanyszerelés az ipari létesítményekben, 
											gyártó üzemekben és más ipari környezetekben használt elektromos rendszerek tervezése, telepítése, karbantartása és javítása.
											Az ipari villanyszerelés magában foglalja a nagyfeszültségű és alacsonyfeszültségű 
											elektromos rendszereket, a motorokat, a vezérlőpaneleket, a fényjelzőket, a szenzorokat, valamint az összes egyéb elektromos berendezést és kábelezést,
											amelyek szükségesek az adott ipari folyamatok biztonságos és hatékony működtetéséhez. Az ipari villanyszerelőknek rendkívül fontos szerepe van a biztonságos
											munkavégzésben és az energiahatékony megoldások kialakításában az ipari területeken.</dd>	 
 											<dt>Kapcsolószekrények</dt>
											<br>
											<dd><p align="justify">A kapcsolószekrényekkel való munkálatok az elektromos vezérlőberendezések telepítését, karbantartását és javítását foglalják magukban.
											Ezek a vezérlőberendezések általában kapcsolószekrényekbe vannak szerelve, amelyek az elektromos áramot irányítják és szabályozzák az adott rendszerben.</dd>
										<a id="electricalAppliances"></a>
										</dl>
									</div>
								</div>

								<hr class="c-divider m-size-small m-transparent">

							</div>
							<!-- PAGE CONTENT ELECTRIC NETWORK: end -->

							<!-- PAGE CONTENT ELECTRIC APPLIANCES: begin -->
							<div id="page-content">

								<h2>Elektromos Eszközök</h2>

								<div class="row">
									<div class="col-md-6">

										<dl>
											<dt>Beszerelés</dt>
											<br>
											<dd><p align="justify">Az elektromos eszközök beszerelése olyan folyamat, amely során az 
																	elektromos készüléket vagy berendezést rögzítik vagy telepítik egy 
																	adott helyre vagy rendszerbe, úgy hogy a működése biztonságos és hatékony
																	legyen. A beszerelés magában foglalja az eszközök előkészítését, az elektromos
																	bekötési munkákat, valamint a szükséges teszteléseket és ellenőrzéseket annak 
																	biztosítása érdekében, hogy az eszköz megfelelően működjön. Az elektromos eszközök
																	beszerelése általában szakértelmet és tapasztalatot igényel, így általában szakemberek végzik.</dd>
											<br>
											<dt>Elektromos eszközök A-Z-ig</dt>
											<br>
											<dd><p align="justify">Az elektromos eszközök széles választékát használják mindennapi életünkben, az egyszerű háztartási készülékektől a bonyolultabb ipari berendezésekig.
											<br>
											<br>		- Beépített világítás
											<br>		- Elektromos háztartási eszközök</dd>
										</dl>
									</div>
									<div class="col-md-6">

										<dl>
											<dt>Cserék</dt>
											<br>
											<dd><p align="justify">Az elektromos eszközök cseréje olyan folyamat,
																	amely során egy meglévő elektromos eszközt eltávolítanak,
																	és egy új eszközt helyeznek el az adott helyen.
																	A cserét általában azért hajtják végre, mert az eredeti
																	eszköz elavulttá vált, meghibásodott, vagy nem felel meg
																	az új igényeknek. Az elektromos eszközök cseréje általában
																	magában foglalja a régi eszköz eltávolítását, az új eszköz
																	telepítését, a bekötési munkákat, valamint a szükséges 
																	teszteléseket és ellenőrzéseket annak biztosítása érdekében,
																	 hogy az új eszköz megfelelően működjön. Az elektromos eszközök
																	cseréjét általában szakemberek végzik, akik rendelkeznek az ehhez
																	szükséges szakértelemmel és tapasztalattal.</dd>
											<dt>Javítás/karbantartás</dt>
											<br>
											<dd><p align="justify">Az elektromos eszközök karbantartása olyan folyamat,
																	amely során az elektromos eszközöket rendszeresen ellenőrzik,
																	tisztítják, javítják és cserélik ki az elhasználódott vagy
																	meghibásodott alkatrészeket annak érdekében, hogy biztosítsák
																	az eszközök biztonságos és hatékony működését.</dd>
											<a id="maintenence"></a>			
										</dl>

									</div>
								</div>

								<hr class="c-divider m-size-small m-transparent">

							</div>
							<!-- PAGE CONTENT ELECTRIC APPLIANCES: end -->

							<!-- PAGE CONTENT MAINTENANCE: begin -->
							<div id="page-content">

								<h2>Karbantartás</h2>

								<div class="row">
									<div class="col-md-6">

										<dl>
											<dt>Épületvillamossági karbantartás</dt>
											<br>
											<dd><p align="justify">Az épületvillamossági karbantartás az épület elektromos rendszerének átvizsgálása, 
												karbantartása és javítása, amely biztosítja a rendszer biztonságos és megbízható működését. Az ilyen karbantartások
												 rendszeresen végezhetők, és szakembereknek kell végezniük őket.</dd>
										</dl>
									</div>
									<div class="col-md-6">
										<dl>
											<dt>Kapcsolószekrények karbantartása</dt>
											<br>
											<dd><p align="justify">A kapcsolószekrények karbantartása az elektromos rendszerben található
												 kapcsolók, biztosítékok és vezérlőegységek átvizsgálása, karbantartása és javítása. Ennek célja a
												  kapcsolószekrények megbízható és hatékony működése, valamint a rendszer biztonságos használata. A karbantartás
												   magában foglalja a szennyeződések eltávolítását, az alkatrészek ellenőrzését és szükség esetén cseréjét, valamint
												    a rendszer teljesítményének és hatékonyságának ellenőrzését is.</dd>
											<a id="surveying"></a>
										</dl>

									</div>
								</div>

								<hr class="c-divider m-size-small m-transparent">


							</div>
							<!-- PAGE CONTENT MAINTENANCE: end -->

							<!-- PAGE CONTENT SURVEYING: begin -->
							<div id="page-content">

								<a id="surveying"><H2>Felmérések</H2></a>

								<div class="row">
									<div class="col-md-6">

										<dl>
											<dt>Elektronikai felmérések</dt>
											<br>
											<dd><p align="justify">Az elektromos eszközök elektronikai felmérései olyan folyamatok,
																	amelyek során mérési és diagnosztikai eszközök segítségével elektromos
																	berendezéseket és áramköröket vizsgálnak annak érdekében, hogy meghatározzák
																	azok működésének állapotát, valamint az esetleges hibák és problémák okait.</dd>
										</dl>
									</div>
									<div class="col-md-6">

										<dl>
											<dt>Tanácsadás</dt>
											<br>
											<dd><p align="justify">Az elektromos tanácsadás olyan szolgáltatás, 
																	amelyet szakemberek nyújtanak az elektromos rendszerek
																	tervezése, építése, karbantartása, javítása és fejlesztése során.
																	Az elektromos tanácsadás során szakemberek segítenek az ügyfeleknek kiválasztani
																	az optimális elektromos rendszereket és eszközöket a szükségleteiknek és 
																	követelményeiknek megfelelően. Az elektromos tanácsadás magában foglalja a projekt
																	tervezését, az anyagok és eszközök beszerzését, a tervezési dokumentáció előkészítését,
																	valamint az ügyfeleknek nyújtott tanácsadást a projekt megvalósítása során.</dd>			
										</dl>

									</div>
								</div>

								<hr class="c-divider m-size-small m-transparent">

							</div>
							<!-- PAGE CONTENT SURVEYING: end -->
							
						</div>
						<div class="col-md-3 col-md-pull-9">

							<hr class="c-divider m-size-large m-type-2 hidden-lg hidden-md">
							<!-- SIDEBAR : begin -->
							<div id="sidebar">
								<div class="sidebar-widget-list">
									<!-- SERVICES WIDGET : begin -->
									<div class="widget services-widget">
										<div class="widget-inner">
											<h3 class="widget-title">Szolgáltatások</h3>
											<ul>
												<li><i class="im im-switch"></i><a href="#networks">Elektromos hálózatok</a></li>
												<li><i class="im im-handdrill"></i><a href="#electricalAppliances">Elektromos eszközök</a></li>
												<li><i class="im im-wrench-screwdriver"></i><a href="#maintenence">Karbantartás</a></li>
												<li><i class="im im-lightning-bolt"></i><a href="#surveying">Felmérések</a></li>
											</ul>
										</div>
									</div>
									<!-- SERVICES WIDGET : end -->

								</div>
							</div>
							<!-- SIDEBAR : end -->

						</div>
					</div>
				</div>

			</div>
			<!-- CORE : end -->

			<!-- FOOTER : begin -->
			<div id="footer" class="m-parallax">

				<!-- FOOTER INNER : begin -->
				<div class="footer-inner">
					<div class="container">

						<!-- BOTTOM PANEL : begin -->
						<div id="bottom-panel">
							<div class="row">
								<div class="col-md-4">

									<!-- TEXT WIDGET : begin -->
									<div class="widget text-widget">
										<div class="widget-inner">
											<h3 class="widget-title"><strong>Rólam</strong></h3>
											<div class="widget-content">

												<p><strong>Vác Villanyszerelés</strong> <br>
												<strong>Elektronikai eszközök</strong> javítása, <strong>lámpák</strong> beszerelése, hálózat <strong>kiépítés,</strong> és <strong>újjáépítés.</strong></p>

											</div>
										</div>
									</div>
									<!-- TEXT WIDGET : end -->

									<hr class="c-divider hidden-lg hidden-md">

								</div>
								<div class="col-md-4">

									<!-- TEXT WIDGET (CONTACT) : begin -->
									<div class="widget text-widget">
										<div class="widget-inner">
											<h3 class="widget-title"><strong>Elérhetőségek</strong></h3>
											<div class="widget-content">

												<p>
												Telefon: <strong>+36 30 283 7830</strong>
												<br> 
												Elérhetőség: <strong>Hétköznap 09:00-16:00</strong>
												<br>
												</p>

											</div>
										</div>
									</div>
									<!-- TEXT WIDGET (CONTACT) : end -->

									<hr class="c-divider hidden-lg hidden-md">

								</div>
								<div class="col-md-4">

									<!-- SUBSCRIBE WIDGET : begin -->
									<div class="widget subscribe-widget">
										<div class="widget-inner">
											<h3 class="widget-title">Írjon <strong>Emailt </strong>bármikor:</h3>
											<div class="widget-content">

												Lépj velem kapcsolatba:
												<strong><a href="mailto:vollai.attila.villanyszereles@gmail.com">vollai.attila.villanyszereles@gmail.com</a></strong>
												<br>
												<br>
									
											</div>
										</div>
									</div>
									<!-- SUBSCRIBE WIDGET : end -->

								</div>
							</div>
						</div>
						<!-- BOTTOM PANEL : end -->

						<div class="row">
							<div class="col-md-6 col-md-push-6">
							</div>
							<div class="col-md-6 col-md-pull-6">
							</div>
						</div>

					</div>
				</div>
				<!-- FOOTER INNER : end -->

			</div>
			<!-- FOOTER : end -->

		<!-- SCRIPTS : begin -->
		<script src="library/js/jquery-1.9.1.min.js" type="text/javascript"></script>
		<script src="library/js/third-party.js" type="text/javascript"></script>
		<script src="library/js/library.js" type="text/javascript"></script>
		<script src="library/js/scripts.js" type="text/javascript"></script>
		<!-- SCRIPTS : end -->

	</body>
</html>