﻿<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Vác Villanyszerelés</title>
        <link rel="shortcut icon" href="images/logo.2x.png">

		<!-- GOOGLE FONTS : begin -->
		<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic%7cExo+2:400,700&amp;subset=latin,latin-ext" rel="stylesheet" type="text/css">
		<!-- GOOGLE FONTS : end -->

        <!-- STYLESHEETS : begin -->
		<link rel="stylesheet" type="text/css" href="library/css/style.css">
        <link rel="stylesheet" type="text/css" href="library/css/skin/default.css">
		<link rel="stylesheet" type="text/css" href="library/css/custom.css">
		<!-- STYLESHEETS : end -->

		<script src="library/js/modernizr.custom.min.js" type="text/javascript"></script>
	</head>
	<body class="m-fixed-header">

		<!-- WRAPPER : begin -->
		<div id="wrapper">

						<!-- HEADER : begin -->
						<header id="header">
							<div class="header-inner">
								<div class="container">
			
									<!-- HEADER BRANDING : begin -->
									<div class="header-branding">
										<div class="branding-inner">
			
											<!-- BRANDING LOGO : begin -->
											<div class="brading-logo">
												<a href="index.php"><img src="images/logo.png" data-hires="images/logo.2x.png" alt="Blue Collar"></a>
											</div>
											<!-- BRANDING LOGO : end -->
			
											<!-- BRANDING INFO : begin -->
											<div class="brading-info">
												<strong>Vollai Attila</strong><br>
												<em>Vác Villanyszerelés</em>
											</div>
											<!-- BRANDING INFO : end -->
			
										</div>
									</div>
									<!-- HEADER BRANDING : end -->
			
									<!-- NAVIGATION TOGGLE : begin -->
									<button class="header-navigation-toggle" type="button"><i class="fa fa-bars"></i></button>
									<!-- NAVIGATION TOGGLE : end -->
			
									<!-- HEADER NAVIGATION : begin -->
									<div class="header-navigation">
										<div class="navigation-inner">
			
											<!-- HEADER MENU : begin -->
											<nav class="header-menu">
												<ul>
													<li>
														<a href="index.php">Főoldal</a>
													</li>
													<li>
														<a href="service-list.php">Szolgáltatások</a>
														<ul>
															<li><a href="service-detail.php">További információ</a></li>
														</ul>
													</li>
													<li>
														<a href="portfolio.php">Portfólió</a>
														<ul>
															<li><a href="previous-works.php">Korábbi munkák</a></li>
														</ul>
													</li>
													<li><a href="contact.php">Kapcsolat</a></li>
												</ul>
											</nav>
											<!-- HEADER MENU : end -->
			
										</div>
									</div>
									<!-- HEADER NAVIGATION : end -->
			
								</div>
							</div>
						</header>
						<!-- HEADER : end -->

			<!-- CORE : begin -->
			<div id="core">

				<!-- PAGE TITLE : begin -->
				<div id="page-title" class="m-parallax">

					<!-- PAGE TITLE TOP : begin -->
					<div class="page-title-top">
						<div class="page-title-top-inner">

							<!-- PAGE TITLE TEXT : begin -->
							<div class="page-title-text">
								<div class="container">
									<h1><strong>404</strong><br>Az oldal nem található</h1>
								</div>
							</div>
							<!-- PAGE TITLE TEXT : end -->

						</div>
					</div>
					<!-- PAGE TITLE TOP : end -->

					<!-- PAGE TITLE BOTTOM : begin -->
					<div class="page-title-bottom">
						<div class="container">
							<div class="page-title-bottom-inner">
								<div class="page-title-bottom-inner2">

									<!-- PAGE TITLE BREADCRUMBS : begin -->
									<div class="page-title-breadcrumbs">
										<ul>
											<li><a href="index.php">Főoldal</a></li>
											<li>404</li>
										</ul>
									</div>
									<!-- PAGE TITLE BREADCRUMBS : end -->

								</div>
							</div>
						</div>
					</div>
					<!-- PAGE TITLE BOTTOM : end -->

				</div>
				<!-- PAGE TITLE : end -->

				<div class="container">

					<!-- PAGE CONTENT : begin -->
					<div id="page-content">

						<!-- SEARCH RESULTS : begin -->
						<div class="search-resultsx">

							<p class="c-alert-message m-warning"><i class="ico fa fa-exclamation-circle"></i>Az oldal amit keres <strong>nem található</strong>, vagy átmenetileg nem elérhető.</p>

							<hr class="c-divider m-size-medium">

						<center><a href="index.php" class="c-button m-type-2 m-size-medium">Vissza a főoldalra</a></center>

						</div>
						<!-- SEARCH RESULTS : end -->

					</div>
					<!-- PAGE CONTENT : end -->

				</div>

			</div>
			<!-- CORE : end -->

			<!-- FOOTER : begin -->
			<div id="footer" class="m-parallax">

				<!-- FOOTER INNER : begin -->
				<div class="footer-inner">
					<div class="container">

						<!-- BOTTOM PANEL : begin -->
						<div id="bottom-panel">
							<div class="row">
								<div class="col-md-4">

									<!-- TEXT WIDGET : begin -->
									<div class="widget text-widget">
										<div class="widget-inner">
											<h3 class="widget-title"><strong>Rólam</strong></h3>
											<div class="widget-content">

												<p><strong>Vác Villanyszerelés</strong> <br>
												<strong>Elektronikai eszközök</strong> javítása, <strong>lámpák</strong> beszerelése, hálózat <strong>kiépítés,</strong> és <strong>újjáépítés.</strong></p>

											</div>
										</div>
									</div>
									<!-- TEXT WIDGET : end -->

									<hr class="c-divider hidden-lg hidden-md">

								</div>
								<div class="col-md-4">

									<!-- TEXT WIDGET (CONTACT) : begin -->
									<div class="widget text-widget">
										<div class="widget-inner">
											<h3 class="widget-title"><strong>Elérhetőségek</strong></h3>
											<div class="widget-content">

												<p>Telefon: <strong>(123) 456 789</strong>
													<br> Elérhetőség: <strong>Hétköznap 10:00-18:00</strong>
												<br>
												</p>

											</div>
										</div>
									</div>
									<!-- TEXT WIDGET (CONTACT) : end -->

									<hr class="c-divider hidden-lg hidden-md">

								</div>
								<div class="col-md-4">

									<!-- SUBSCRIBE WIDGET : begin -->
									<div class="widget subscribe-widget">
										<div class="widget-inner">
											<h3 class="widget-title">Írj nekem <strong>Emailt </strong>bármikor:</h3>
											<div class="widget-content">
													Lépj velem kapcsolatba:
													<strong><a href="mailto:vollai.attila.villanyszereles@gmail.com">vollai.attila.villanyszereles@gmail.com</a></strong>
												<br>
												<br>
											</div>
										</div>
									</div>
									<!-- SUBSCRIBE WIDGET : end -->

								</div>
							</div>
						</div>
						<!-- BOTTOM PANEL : end -->

						<div class="row">
							<div class="col-md-6 col-md-push-6">
							</div>
							<div class="col-md-6 col-md-pull-6">
							</div>
						</div>

					</div>
				</div>
				<!-- FOOTER INNER : end -->

			</div>
			<!-- FOOTER : end -->

		</div>
		<!-- WRAPPER : END -->

		<!-- SCRIPTS : begin -->
		<script src="library/js/jquery-1.9.1.min.js" type="text/javascript"></script>
		<script src="library/js/third-party.js" type="text/javascript"></script>
		<script src="library/js/library.js" type="text/javascript"></script>
		<script src="library/js/scripts.js" type="text/javascript"></script>
		<!-- SCRIPTS : end -->
	</body>
</html>