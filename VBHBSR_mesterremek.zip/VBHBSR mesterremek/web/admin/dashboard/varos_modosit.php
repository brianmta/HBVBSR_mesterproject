<?php
    require_once('header.php');
    require_once('functions/func_varos_modosit.php');
 
    if (isset($_GET['id'])){
        $id = $_GET['id'];
        $varos = varos_lekerdez_id_alapjan($id);
    }
	
    if (isset($_POST['modosit'])){
        varos_modosit(); 
    }
?>
<center>
<div class="container mt-3">
    <div class="row">
        <div class="col-sm-12">
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <div class="col-sm-6">
                    <div class="form-group width">
                        <label for="iranyitoszam">Irányítószám:</label>
                        <input type="text" class="form-control" name="iranyitoszam" id="iranyitoszam" value="<?php echo $varos['iranyitoszam']; ?>" placeholder="pl.: 1234" required>
                    </div>  
                    <div class="form-group width">
                        <label for="varos">Város:</label>
                        <input type="text" class="form-control" name="varos" id="varos" value="<?php echo $varos['varos']; ?>" placeholder="pl.: Budapest" required>
                    </div>  
                </div> 
				<br>
                <a href="javascript:history.back()" class="btn btn-warning mt-3">Mégsem</a> 
                <input type="submit" name="modosit" value="Módosít" class="btn btn-success mt-3"> 
            </form>
        </div> 
    </div> 
</div>
</center>

<style>
	.width {
		width: 250px;
	}
</style>

</div>
</div>
</body>
</html>