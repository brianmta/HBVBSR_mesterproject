<?php
    require_once('header.php');
    require_once('functions/func_varos_torol.php');

    if (isset($_GET['id'])){
        $id = $_GET['id'];
    }

    if (isset($_POST['torol'])){
        varos_torol(); 
    }
?>

<div class="container mt-3">
    <div class="col-sm-12">
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
            <center>
				<input type="hidden" name="id" value="<?php echo $id; ?>">
			
<style>
    .delete-warning{
        font-size: 32px;

    }
</style>

				<p class="delete-warning">Biztosan törli?</p>              
				<a href="javascript:history.back()" class="btn btn-warning">Mégsem</a> 
				<input type="submit" name="torol" value="Töröl" class="btn btn-danger">
            </center>
        </form>
    </div> 
</div> 

</div>
</div>
</body>
</html>