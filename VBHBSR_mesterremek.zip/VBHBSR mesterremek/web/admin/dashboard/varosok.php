<?php
    require_once('header.php');
    require_once('functions/func_varosok_listaz.php');
    require_once('functions/func_varos_uj.php');
    $varosok = varosok_lekerdez();
	
    if (isset($_POST['ment'])){
        varos_felvitel(); 
    }
?>

<center>
	<div class="container mt-3">
		<div class="row">
			<div class="col-sm-12">
				<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
					<input type="hidden" name="id" value="<?php echo $id; ?>">
					<div class="col-sm-6">
						<legend align="center" style="text-transform: uppercase; background-color:lavender;">Városok</legend>
						<br><br>
						<div class="form-group">
							<label for="iranyitoszam">Új város irányítószáma:</label>
							<input type="text" class="form-control width" name="iranyitoszam" id="iranyitoszam" placeholder="pl.: 0000" pattern="[0-9]{4}" required>
						</div> 
						<br>
						<div class="form-group">
							<label for="varos">Új város neve:</label>
							<input type="text" class="form-control width" name="varos" id="varos" placeholder="pl.: Vác" maxlength="30" required>
						</div> 
						<br>
						<input type="submit" name="ment" value="Hozzáad" class="btn btn-success mt-3">
						<br><br>

<style>
	hr.dashed {
		border-top: 3px solid black;
	}
	
	.text-centered{
        text-align: center;
	}
	.width {
		width: 250px;
	}
</style>

						<hr class="dashed">
						<br>
						<table class="table table-hover table-sm table-bordered">
							<thead>
								<th><Center>Irányítószám</center></th>
								<th><Center>Város</center></th>
								<th colspan="2"><Center>Műveletek</center></th>
							</thead>
							<tbody class="text-centered">
<?php
    foreach ($varosok as $varos){
        echo "<tr>";
        echo "<td>". $varos['iranyitoszam']. "</td>";
        echo "<td>". $varos['varos']. "</td>";
        echo "<td>". '<a class="btn btn-warning" href="varos_modosit.php?id='. $varos['id'].'"> ✎ </a> '. "</td>";
        echo "<td>". '<a class="btn btn-danger" href="varos_torol.php?id='. $varos['id'].'"> 🗑 </a>'. "</td>"; 
	}
?>
							</tbody>
						</table>
					</div>
				</form>	
			</div>
		</div>
	</div>		
</center> 

</div>
</div>
</body>
</html>     