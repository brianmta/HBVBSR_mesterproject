<?php
    session_start();

    if (!isset($_SESSION['userId'])) {
        $url = "../index.php";
        header("Location: ".$url);
        exit();
    }
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script>
    <title>Adminisztrációs felület</title>
    <link rel="shortcut icon" href="../../images/logo.2x.png">
</head>
<body>
    <center>
    <div class="row">
        <div class="jumbotron bg-info text-white pt-3 pb-3">
            <h1 class="display3 text-center"><b>Vác Villanyszerelés</b></h1>
            <h5 class="display3 text-center">Adminisztrációs felület</h5>
        </div>
    </div>  
	<br>
    <a href="megrendelesek_listaz.php"> <button class="btn btn-outline-success marginsForButton" type="button">Megrendelések</button></a>  
	<a href="varosok.php">  <button class="btn btn-outline-success marginsForButton" type="button">Városok</button></a> 
	<a href="munka_jellegek.php"> <button class="btn btn-outline-success marginsForButton" type="button">Munka jellegek</button></a> 

<style>
	.dropdown {
		position: relative;
		display: inline-block;
	}

	.dropdown-content {
		display: none;
		position: relative;
		background-color: #f1f1f1;
		min-width: 160px;
		box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
		z-index: 1;
		text-align: center;
		max-width: max-content;
		margin: auto;
	}

	.dropdown-content a {
		color: black;
		padding: 12px 16px;
		text-decoration: none;
		display: inline-block;
		position: relative;
	}

	.dropdown-content a:hover {background-color: #ddd;}

	.dropdown:hover .dropdown-content {display: block;}

	.dropdown:hover .dropbtn {background-color: #3e8e41;}

	.marginsForButton{
		margin: 10px 5px 10px 5px;
		max-width: max-content;
	}

	hr.dashed {
		border-top: 3px solid ;
	}

	html, body {
		max-width: 100%;
		overflow-x: hidden;
	}
</style>
	<a href="logout.php"> <button class="btn btn-outline-danger marginsForButton" type="button">Kilépés</button></a> 
	<br>
	<div class="dropdown">
	<button class="btn btn-outline-secondary marginsForButton">Megrendelések rendezése</button>
		<div class="dropdown-content">
			<a href="megrendelesek_listaz_datum.php">Megrendelés dátuma</a>
			<a href="megrendelesek_listaz_start.php">Kezdés dátuma</a>
			<a href="megrendelesek_listaz_statusz.php">Státusz</a>
		</div>
	</div>
	</center>
	<hr class="dashed">
	<br>
 