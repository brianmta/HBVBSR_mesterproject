<?php
    require_once('header.php');
    require_once('functions/func_megrendeles_torol.php');

    if (isset($_GET['id'])){
        $id = $_GET['id'];
    }

    if (isset($_POST['torol'])){
        megrendeles_torol(); 
    }
?>
<div class="container mt-3">
    <div class="row">
        <div class="col-sm-12">
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
            <div class="row">
                <div class="form-group" style="text-align: center">
                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                    <p>Tényleg törli a(z) <?php echo $id; ?> ID-jú megrendelést?</p>              
                    <a href="javascript:history.back()" class="btn btn-warning">Mégsem</a> 
                    <input type="submit" name="torol" value="Töröl" class="btn btn-danger">
                </div>  
            </div> 
            </form>
        </div> 
    </div> 
</div>


</div>      
</div>
</body>
</html>