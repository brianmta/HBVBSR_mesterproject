<?php
    require_once('header.php');
    require_once('functions/func_megrendeles_modosit.php');
    require_once('functions/func_megrendeles_lekerdez_varos.php');
    require_once('functions/func_megrendeles_lekerdez_munka_jell.php');
    require_once('functions/func_megrendeles_lekerdez_statusz.php');
 
    if (isset($_GET['id'])){
        $id = $_GET['id'];
        $megrendeles = megrendeles_lekerdez_id_alapjan($id);
    }
    
    $varos_kategoriak = varos_kategoriak_lekerdez();
    $munka_jell_kategoriak = munka_jell_kategoriak_lekerdez();
    $statusz_kategoriak = statusz_kategoriak_lekerdez();

    if (isset($_POST['modosit'])){
        megrendeles_modosit(); 
    }

?>

<style>
	.width {
		width: 350px;
	}
</style>

<center>
<div class="container mt-3">
    <div class="row">
        <div class="col-sm-12">
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="megrend_datum">Megrendelés dátuma</label>
                        <input type="text" class="form-control width" name="megrend_datum" id="megrend_datum" value="<?php echo $megrendeles['megrend_datum']; ?>" disabled placeholder="Megrendelés dátuma" required>
                    </div>
                    <br> 
                    <div class="form-group">
                        <label for="kezdodatum">Kezdődátum</label>
                        <input type="datetime-local" class="form-control width" value="<?php echo $megrendeles['kezdodatum']; ?>" name="kezdodatum" id="kezdodatum" placeholder="Kezdődátum" pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}">
                    </div> 
                    <br>
                    <div class="form-group">
                        <label for="ugyfel_nev">Ügyfél neve</label>
                        <input type="text" class="form-control width" name="ugyfel_nev" id="ugyfel_nev" pattern="[a-zA-ZÁáÉéÍíÓóÖöŐőÚúÜüŰű-]+\s[a-zA-ZÁáÉéÍíÓóÖöŐőÚúÜüŰű-]+" maxlength="100" title="A névnek tartalmaznia kell a teljes nevet, valamint csak betűt és kötőjelet (-) tartalmazhat." value="<?php echo $megrendeles['ugyfel_nev']; ?>" placeholder="pl.: Teszt Elek" required>
                    </div>
                    <br>
                    <div class="form-group">
                        <label for="varos_id">Város</label>
                        <select name="varos_id" id="varos_id" class="form-select width">
                        <?php
                            $selected = ""; 
                            foreach ($varos_kategoriak as $varos_kategoria) {
                                $varos_kategoria['id'] == $megrendeles['varos_id'] ? $selected = "selected" : $selected = "";
                                echo "<option value=".$varos_kategoria['id']." $selected>".$varos_kategoria['varos']."</option>";
                            }
                        ?>
                        </select>
                    </div> 
                    <br>
                    <div class="form-group">
                        <label for="ugyfel_cim">Ügyfél címe</label>
                        <input type="text" class="form-control width" name="ugyfel_cim" id="ugyfel_cim" pattern="[a-zA-ZÁáÉéÍíÓóÖöŐőÚúÜüŰű\d\s\.,\-\/]{5,100}" placeholder="pl.: Petőfi Sándor utca 1." title="Címe minimum 5 és maximum 100 karakter hosszú lehet, valamint csak betűket, számokat, és bizonyos speciális karaktereket tartalmazhat (. , - /)" value="<?php echo $megrendeles['ugyfel_cim']; ?>" required>
                    </div>  
                    <br>
                    <div class="form-group">
                        <label for="ugyfel_email">Ügyfél email címe</label>
                        <input type="text" class="form-control width" name="ugyfel_email" id="ugyfel_email" maxlength="100" value="<?php echo $megrendeles['ugyfel_email']; ?>" placeholder="pl.: tesztelek@gmail.com" required>
                    </div> 
                    <br> 
                    <div class="form-group">
                        <label for="ugyfel_tel">Ügyfél telefonszáma</label>
                        <input type="text" class="form-control width" name="ugyfel_tel" id="ugyfel_tel" pattern="\+36\d{1,9}" placeholder="pl.: +36301234567" title="A telefonszámnak '+36'-tal kell kezdődnie, majd csak számokat tartalmazhat." value="<?php echo $megrendeles['ugyfel_tel']; ?>" required>
                    </div>   
                    <br> 
                    <div class="form-group">
                        <label for="munka_jell_id">Munka jellege</label>
                        <select name="munka_jell_id" id="munka_jell_id" class="form-select width">
                        <?php
                            $selected = ""; 
                            foreach ($munka_jell_kategoriak as $munka_jell_kategoria) {
                                $munka_jell_kategoria['id'] == $megrendeles['munka_jell_id'] ? $selected = "selected" : $selected = "";
                                echo "<option value=".$munka_jell_kategoria['id']." $selected>".$munka_jell_kategoria['megnevezes']."</option>";
                            }
                        ?>
                        </select>
                    </div> 
                    <br>
                    <div class="form-group">
                        <label for="uzenet">Üzenet</label>
                        <textarea class="form-control width" name="uzenet" id="uzenet" maxlength="255" style="resize: none;" rows="3" pattern="[a-zA-ZÁáÉéÍíÓóÖöŐőÚúÜüŰű\d\s\.,;:\-\+\?\!\(\)\[\]\{\}\\'/=%]" placeholder="Az ügyfél üzenete (max. 255 karakter)." maxlength="255" title="Üzenete maximum 255 karakter hosszú lehet, valamint csak betűket, számokat, és bizonyos speciális karaktereket tartalmazhat (. , ; : - + ? ! ( ) [ ] { } \ ' / = %)"><?php echo $megrendeles['uzenet']; ?>
                        </textarea>
                    </div>
                    <br>
                    <div class="form-group">
                        <label for="statusz_id">Munka státusza</label>
                        <select name="statusz_id" id="statusz_id" class="form-select width">
                        <?php
                            $selected = ""; 
                            foreach ($statusz_kategoriak as $statusz_kategoria) {
                                $statusz_kategoria['id'] == $megrendeles['statusz_id'] ? $selected = "selected" : $selected = "";
                                echo "<option value=".$statusz_kategoria['id']." $selected>".$statusz_kategoria['megnevezes']."</option>";
                            }
                        ?>
                        </select>
                    </div> 
                    <br>
                    <a href="javascript:history.back()" class="btn btn-warning mt-3">Mégsem</a> 
                    <input type="submit" name="modosit" value="Módosít" class="btn btn-success mt-3">
                    <br><br>
				</div>
			</form>
        </div> 
    </div> 
</div>
</center>

</div>      
</div>
</body>
</html>