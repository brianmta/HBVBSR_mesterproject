<?php
    require_once('db_connect.php');

    function varos_felvitel(){
        $mysqli = db_connect();
        $varos = $_POST['varos'];
        $iranyitoszam = $_POST['iranyitoszam'];
        $sql = "INSERT INTO varosok (varos, iranyitoszam) VALUES ('$varos','$iranyitoszam')";
        $eredmeny = $mysqli->query($sql);
    
        if ($eredmeny) {
            $url = './varosok.php';
            header('Location: ' . $url);
            } else {   
                echo $mysqli->error;
        } 
        mysqli_close($mysqli);
    }
?>