<?php
    require_once('db_connect.php');

    function munka_jell_kategoriak_lekerdez(){
        $mysqli = db_connect();
        $sql = "SELECT * FROM munka_jell";
        $eredmeny = $mysqli->query($sql);
        if ($eredmeny){
            while ($sor = mysqli_fetch_assoc($eredmeny)){
                $munka_jell_kategoriak[] = $sor;
            }
        } else {
            die("SQL hiba: ".$mysqli->error);
        }
        mysqli_close($mysqli);
    return $munka_jell_kategoriak;
    }
?>