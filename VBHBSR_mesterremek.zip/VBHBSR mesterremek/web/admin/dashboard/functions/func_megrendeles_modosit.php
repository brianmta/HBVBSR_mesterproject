<?php
    require_once('db_connect.php');

    function megrendeles_lekerdez_id_alapjan($id){
        $mysqli = db_connect();
        $sql = "SELECT * FROM `megrendelesek` WHERE `id` = '$id'";
        $eredmeny = $mysqli->query($sql);
        $megrendeles = mysqli_fetch_assoc($eredmeny);
        return $megrendeles;
    }

    function megrendeles_modosit(){
        $mysqli = db_connect();
        $id = $_POST['id'];
        $megrend_datum = $_POST['megrend_datum'];
        $kezdodatum = $_POST['kezdodatum'];
        $ugyfel_nev = $_POST['ugyfel_nev'];
        $varos_id = $_POST['varos_id'];
        $ugyfel_cim = $_POST['ugyfel_cim'];
        $ugyfel_tel = $_POST['ugyfel_tel'];
        $ugyfel_email = $_POST['ugyfel_email'];
        $munka_jell_id = $_POST['munka_jell_id'];
        $uzenet = trim($_POST['uzenet']);
        $statusz_id = $_POST['statusz_id'];
       
        $sql = "UPDATE `megrendelesek` SET
        `kezdodatum` = '$kezdodatum',`ugyfel_nev` = '$ugyfel_nev',`varos_id` = '$varos_id', 
        `ugyfel_cim` = '$ugyfel_cim',`ugyfel_tel` = '$ugyfel_tel',`ugyfel_email` = '$ugyfel_email',`munka_jell_id` = '$munka_jell_id',
        `uzenet` = '$uzenet', `statusz_id` = '$statusz_id' WHERE `id`='$id'";

        $eredmeny = $mysqli->query($sql);
        if ($eredmeny){
            $url = "index.php";
            header('Location: ' . $url);
        } else {
            echo $mysqli->error;
        }
        mysqli_close($mysqli);
    }
?>