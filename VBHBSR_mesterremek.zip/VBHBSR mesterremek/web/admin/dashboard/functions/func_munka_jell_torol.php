<?php
    require_once('db_connect.php');
   
    function munka_jell_torol(){
        $mysqli = db_connect();
        $id = $_POST['id'];
        $sql = "DELETE FROM munka_jell WHERE id = '$id'";
        $eredmeny = $mysqli->query($sql);
        if ($eredmeny) {
            $url = './munka_jellegek.php';
            header('Location: ' . $url);
        } else {   
            echo $mysqli->error;
        } 
        mysqli_close($mysqli);
    }
?>

        
        
      


