<?php
    require_once('db_connect.php');
   
    function varos_torol(){
        $mysqli = db_connect();
        $id = $_POST['id'];
        $sql = "DELETE FROM varosok WHERE id = '$id'";
        $eredmeny = $mysqli->query($sql);
        if ($eredmeny) {
            $url = './varosok.php';
            header('Location: ' . $url);
        } else {   
            echo $mysqli->error;
        } 
        mysqli_close($mysqli);
    }
?>

        
        
      


