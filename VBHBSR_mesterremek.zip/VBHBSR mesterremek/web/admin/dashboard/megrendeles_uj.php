<?php
    require_once('header.php');
    require_once('functions/func_megrendeles_felvitel.php');

    if (isset($_POST['ment'])){
        megrendeles_felvitel(); 
    }
?>
<center>
<div class="container mt-3">
    <div class="row">
        <div class="col-sm-12">
			<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
				<input type="hidden" name="id">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="megrend_datum">Megrendelés dátuma</label>
                        <input type="text" class="form-control" name="megrend_datum" id="megrend_datum" placeholder="2023-3-1" required>
                    </div> 
                    <div class="form-group">
                        <label for="kezdodatum">Kezdődátum</label>
                        <input type="text" class="form-control" name="kezdodatum" id="kezdodatum" placeholder="2023-1-12 14:00:00" required>
                    </div> 
                    <div class="form-group">
                        <label for="ugyfel_nev">Ügyfél neve</label>
                        <input type="text" class="form-control" name="ugyfel_nev" id="ugyfel_nev" placeholder="Kossuth Lajos" required>
                    </div>
                    <div class="form-group">
                        <label for="varos_id">Város</label>
                        <select name="varos_id" id="varos_id" class="form-select">
                        <?php 
							$mysqli = db_connect();
							$sql = "SELECT id, varos FROM varosok ORDER BY varos";
							$rows = $mysqli->query($sql);
							while ($row = $rows->fetch_assoc()){
								echo '<option value="'.$row['id'].'">'.$row['varos'].'</option>';
							}
							mysqli_close($mysqli);
						?>
                        </select>
                    </div> 
                    <div class="form-group">
                        <label for="ugyfel_cim">Ügyfél címe</label>
                        <input type="text" class="form-control" name="ugyfel_cim" id="ugyfel_cim" placeholder="Petőfi utca 1" required>
                    </div>  
                    <div class="form-group">
                        <label for="ugyfel_email">Ügyfél email címe</label>
                        <input type="text" class="form-control" name="ugyfel_email" id="ugyfel_email" placeholder="email.cim@gmail.com" required>
                    </div>  
                    <div class="form-group">
                        <label for="ugyfel_tel">Ügyfél telefonszáma</label>
                        <input type="text" class="form-control" name="ugyfel_tel" id="ugyfel_tel" placeholder="0630..." required>
                    </div>    
                    <div class="form-group">
                        <label for="munka_jell_id">Munka jellege</label>
                        <select name="munka_jell_id" id="munka_jell_id" class="form-select">
                        <?php 
							$mysqli = db_connect();
							$sql = "SELECT id, megnevezes FROM munka_jell ORDER BY megnevezes";
							$rows = $mysqli->query($sql);
							while ($row = $rows->fetch_assoc()){
								echo '<option value="'.$row['id'].'">'.$row['megnevezes'].'</option>';
							}
							mysqli_close($mysqli);
						?>
                        </select>
                    </div> 
                    <div class="form-group">
                        <label for="uzenet">Ügyfél üzenete</label>
                        <textarea class="form-control" name="uzenet" id="uzenet" rows="3">
                        </textarea>
                    </div>
                    <div class="form-group">
                        <label for="statusz_id">Munka státusza</label>
                        <select name="statusz_id" id="statusz_id" class="form-select">
                        <?php 
							$mysqli = db_connect();
							$sql = "SELECT id, megnevezes FROM statuszok ORDER BY megnevezes";
							$rows = $mysqli->query($sql);
							while ($row = $rows->fetch_assoc()){
								echo '<option value="'.$row['id'].'">'.$row['megnevezes'].'</option>';
							}
							mysqli_close($mysqli);
						?>
                        </select>
                    </div> 
                    <a href="javascript:history.back()" class="btn btn-warning mt-3">Mégsem</a> 
                    <input type="submit" name="ment" value="Új rendelés hozzáadása" class="btn btn-success mt-3">
				</div> 
			</form>
        </div> 
    </div> 
</div>
</center>

</div>      
</div>
</body>
</html>