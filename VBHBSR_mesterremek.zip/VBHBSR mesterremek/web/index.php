﻿
<!DOCTYPE html>
<html>
	<head>

		<meta http-equiv="content-type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Vác Villanyszerelés</title>
        <link rel="shortcut icon" href="images/logo.2x.png">

		<!-- GOOGLE FONTS : begin -->
		<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic%7cExo+2:400,700&amp;subset=latin,latin-ext" rel="stylesheet" type="text/css">
		<!-- GOOGLE FONTS : end -->

        <!-- STYLESHEETS : begin -->
		<link rel="stylesheet" type="text/css" href="library/css/style.css">
        <link rel="stylesheet" type="text/css" href="library/css/skin/default.css">
		<link rel="stylesheet" type="text/css" href="library/css/custom.css">
		
		<!-- STYLESHEETS : end -->

        <!--[if lte IE 8]>
			<link rel="stylesheet" type="text/css" href="library/css/oldie.css">
			<script src="library/js/respond.min.js" type="text/javascript"></script>
        <![endif]-->
		<script src="library/js/modernizr.custom.min.js" type="text/javascript"></script>

	</head>
	<body class="m-fixed-header">

		<!-- WRAPPER : begin -->
		<div id="wrapper">

					<!-- HEADER : begin -->
					<header id="header">
						<div class="header-inner">
							<div class="container">
		
								<!-- HEADER BRANDING : begin -->
								<div class="header-branding">
									<div class="branding-inner">
		
										<!-- BRANDING LOGO : begin -->
										<div class="brading-logo">
											<a href="index.php"><img src="images/logo.png" data-hires="images/logo.2x.png" alt="Blue Collar"></a>
										</div>
										<!-- BRANDING LOGO : end -->
		
										<!-- BRANDING INFO : begin -->
										<div class="brading-info">
											<strong>Vollai Attila</strong><br>
											<em>Vác Villanyszerelés</em>
										</div>
										<!-- BRANDING INFO : end -->
		
									</div>
								</div>
								<!-- HEADER BRANDING : end -->
		
								<!-- NAVIGATION TOGGLE : begin -->
								<button class="header-navigation-toggle" type="button"><i class="fa fa-bars"></i></button>
								<!-- NAVIGATION TOGGLE : end -->
		
								<!-- HEADER NAVIGATION : begin -->
								<div class="header-navigation">
									<div class="navigation-inner">
		
										<!-- HEADER MENU : begin -->
										<nav class="header-menu">
											<ul>
												<li class="m-active">
													<a href="index.php">Főoldal</a>
												</li>
												<li>
													<a href="service-list.php">Szolgáltatások</a>
													<ul>
														<li><a href="service-detail.php">További információ</a></li>
													</ul>
												</li>
												<li>
													<a href="portfolio.php">Rólam</a>
													<ul>
														<li><a href="previous-works.php">Korábbi munkáim</a></li>
													</ul>
												</li>
												<li><a href="contact.php">Kapcsolat</a></li>
											</ul>
										</nav>
										<!-- HEADER MENU : end -->
		
									</div>
								</div>
								<!-- HEADER NAVIGATION : end -->
		
							</div>
						</div>
					</header>
					<!-- HEADER : end -->
			<!-- CORE : begin -->
			<div id="core">

				<!-- PAGE TITLE : begin -->
				<div id="page-title" class="m-parallax">

					<!-- PAGE TITLE TOP : begin -->
					<div class="page-title-top">
						<div class="page-title-top-inner">

							<!-- PAGE TITLE TEXT : begin -->
							<div class="page-title-text">
								<div class="container">
									<h1>Villanyszerelés<br><strong>Vácon és környékén</strong>!</h1>
								</div>
							</div>
							<!-- PAGE TITLE TEXT : end -->

						</div>
					</div>
					<!-- PAGE TITLE TOP : end -->

					<!-- PAGE TITLE BOTTOM : begin -->
					<div class="page-title-bottom">
						<div class="container">
							<div class="page-title-bottom-inner">
								<div class="page-title-bottom-inner2">

									<!-- PAGE TITLE BAR : begin -->
									<div class="page-title-bar">
										<div class="page-title-bar-inner">

											<ul class="page-title-bar-left">
												<li><i class="fa fa-phone"></i><strong>+36 30 283 7830</strong></li>
												<li><i class="fa fa-envelope-o"></i><strong><a href="mailto:vollai.attila.villanyszereles@gmail.com">vollai.attila.villanyszereles@gmail.com</a></strong></li>
											</ul>

											<div class="page-title-bar-right">
												<a href="contact.php" class="c-button m-type-2 m-size-medium">Lássunk munkához!</a>
											</div>

										</div>
									</div>
									<!-- PAGE TITLE BAR : end -->

								</div>
							</div>
						</div>
					</div>
					<!-- PAGE TITLE BOTTOM : end -->

				</div>
				<!-- PAGE TITLE : end -->

				<!-- PAGE CONTENT : begin -->
				<div id="page-content">

					<!-- INTRO SECTION : begin -->
					<section class="c-section">
						<div class="section-inner">
							<div class="container">

								<div class="row">
									<div class="col-md-4">

										<center><p class="hidden-sm hidden-xs"><img height="450px" width="512px" src="images/avatar.png" alt="profile_picture"></p></center>

									</div>
									<div class="col-md-8">

										<hr class="c-divider m-transparent m-size-medium hidden-xs hidden-sm hidden-md">
										<h2><strong>Több mint 20 évnyi tapasztalat</strong><br>villanyszerelésben.</h2>
										<h4><p>Bejelentett munkahely mellett egyéni vállalkozóként is napi szinten foglalkozok villanyszereléssel, több mint 20 éve.</p></h4>
										<p><a href="portfolio.php" class="c-button m-type-2 m-size-medium">Tudj meg többet rólam!</a></p>

									</div>
								</div>

							</div>
						</div>
					</section>
					<!-- INTRO SECTION : end -->

					<!-- ARTICLES SECTION : begin -->
					<section class="c-section">
						<div class="section-inner">
							<div class="container">

								<h2>Tekintsd meg <strong>korábbi munkáimat</strong>!</h2>

								<!-- CAROUSEL : begin -->
								<div class="c-carousel" data-autoplay="0" data-loop="false"
									data-items-show="3" data-items-under-1199="3" data-items-under-991="2" data-items-under-767="2" data-items-under-480="1">
									<div class="c-carousel-items">

										<!-- ARTICLE LIST: begin -->
										<div class="c-article-list">


											<!-- ARTICLE : begin -->
											<article class="c-article">
												<div class="article-inner">
													<div class="article-image">
														<a href="previous-works.php"><img src="images/elektromos_halozat.jpg" height="275" alt="Elektromos hálózat"></a>
													</div>
													<div class="article-content">
														<div class="content-inner">
															<center><h2 class="article-title"><a href="previous-works.php">Betonüzem elektromos hálózatának kiépítése</a></h2></center>
														</div>
													</div>
												</div>
											</article>
											<!-- ARTICLE : end -->

											<!-- ARTICLE : begin -->
											<article class="c-article">
												<div class="article-inner">
													<div class="article-image">
														<a href="previous-works.php"><img src="images/forgacsuzem.jpg" height="275" alt="Forgácsüzem"></a>
													</div>
													<div class="article-content">
														<div class="content-inner">
															<center><h2 class="article-title"><a href="previous-works.php">Forgácsüzem felújítása és karbantartása</a></h2></center>
														</div>
													</div>
												</div>
											</article>
											<!-- ARTICLE : end -->

											<!-- ARTICLE : begin -->
											<article class="c-article">
												<div class="article-inner">
													<div class="article-image">
														<a href="previous-works.php#article3-4"><img src="images/konnyuszerkezetes_haz.jpg" height="275" alt="Könnyűszerkezetes ház"></a>
													</div>
													<div class="article-content">
														<div class="content-inner">
															<center><h2 class="article-title"><a href="previous-works.php">Könnyűszerkezetes házak villanyszerelése</a></h2></center>
														</div>
													</div>
												</div>
											</article>
											<!-- ARTICLE : end -->


											<!-- ARTICLE : begin -->
											<article class="c-article">
												<div class="article-inner">
													<div class="article-image">
														<a href="previous-works.php#article3-4"><img src="images/ronkhaz.jpg" height="275" alt="Rönkház"></a>
													</div>
													<div class="article-content">
														<div class="content-inner">
															<center><h2 class="article-title"><a href="previous-works.php">Rönkház villanyszerelése és karbantartása</a></h2></center>
														</div>
													</div>
												</div>
											</article>
											<!-- ARTICLE : end -->

										</div>
										<!-- ARTICLE LIST : end -->

									</div>
								</div>
								<!-- CAROUSEL : end -->

							</div>
						</div>
					</section>
					<!-- ARTICLES SECTION : end -->

				</div>
				<!-- PAGE CONTENT : end -->

			</div>
			<!-- CORE : end -->

			<!-- FOOTER : begin -->
			<div id="footer" class="m-parallax">

				<!-- FOOTER INNER : begin -->
				<div class="footer-inner">
					<div class="container">

						<!-- BOTTOM PANEL : begin -->
						<div id="bottom-panel">
							<div class="row">
								<div class="col-md-4">

									<!-- TEXT WIDGET : begin -->
									<div class="widget text-widget">
										<div class="widget-inner">
											<h3 class="widget-title"><strong>Rólam</strong></h3>
											<div class="widget-content">

												<p><strong>Vác Villanyszerelés</strong> <br>
												<strong>Elektronikai eszközök</strong> javítása, <strong>lámpák</strong> beszerelése, hálózat <strong>kiépítés,</strong> és <strong>újjáépítés.</strong></p>

											</div>
										</div>
									</div>
									<!-- TEXT WIDGET : end -->

									<hr class="c-divider hidden-lg hidden-md">

								</div>
								<div class="col-md-4">

									<!-- TEXT WIDGET (CONTACT) : begin -->
									<div class="widget text-widget">
										<div class="widget-inner">
											<h3 class="widget-title"><strong>Elérhetőségek</strong></h3>
											<div class="widget-content">

												<p>Telefon: +36 30 283 7830 <strong></strong>
												<br>
												Elérhetőség: <strong>Hétköznap 9:00-16:00</strong>
												<br>
												</p>

											</div>
										</div>
									</div>
									<!-- TEXT WIDGET (CONTACT) : end -->

									<hr class="c-divider hidden-lg hidden-md">

								</div>
								<div class="col-md-4">

									<!-- SUBSCRIBE WIDGET : begin -->
									<div class="widget subscribe-widget">
										<div class="widget-inner">
											<h3 class="widget-title">Írj nekem <strong>Emailt </strong>bármikor:</h3>
											<div class="widget-content">

													Lépj velem kapcsolatba:
													<strong><a href="mailto:vollai.attila.villanyszereles@gmail.com">vollai.attila.villanyszereles@gmail.com</a></strong>
													<br>
													<br>
											</div>
										</div>
									</div>
									<!-- SUBSCRIBE WIDGET : end -->

								</div>
							</div>
						</div>
						<!-- BOTTOM PANEL : end -->

						<div class="row">
							<div class="col-md-6 col-md-push-6">
							</div>
							<div class="col-md-6 col-md-pull-6">
							</div>
						</div>

					</div>
				</div>
				<!-- FOOTER INNER : end -->

			</div>
			<!-- FOOTER : end -->

		</div>
		<!-- WRAPPER : END -->

		<!-- SCRIPTS : begin -->
		<script src="library/js/jquery-1.9.1.min.js" type="text/javascript"></script>
		<script src="library/js/third-party.js" type="text/javascript"></script>
		<script src="library/js/library.js" type="text/javascript"></script>
		<script src="library/js/scripts.js" type="text/javascript"></script>
		<!-- SCRIPTS : end -->

	</body>
</html>