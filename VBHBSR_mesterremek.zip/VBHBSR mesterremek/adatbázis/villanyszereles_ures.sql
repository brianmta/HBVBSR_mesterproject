-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 172.17.0.1:3306
-- Létrehozás ideje: 2023. Ápr 17. 13:07
-- Kiszolgáló verziója: 8.0.29-21
-- PHP verzió: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `villanyszereles`
--
CREATE DATABASE IF NOT EXISTS `villanyszereles` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `villanyszereles`;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `admin`
--

CREATE TABLE `admin` (
  `id` int NOT NULL,
  `user` varchar(25) CHARACTER SET utf8mb3 COLLATE utf8_hungarian_ci NOT NULL,
  `jelszo` varchar(40) CHARACTER SET utf8mb3 COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_hungarian_ci;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `megrendelesek`
--

CREATE TABLE `megrendelesek` (
  `id` mediumint NOT NULL,
  `megrend_datum` datetime NOT NULL,
  `kezdodatum` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
  `ugyfel_nev` varchar(100) CHARACTER SET utf32 COLLATE utf32_hungarian_ci NOT NULL,
  `varos_id` smallint NOT NULL,
  `ugyfel_cim` varchar(100) CHARACTER SET utf32 COLLATE utf32_hungarian_ci NOT NULL,
  `ugyfel_email` varchar(100) CHARACTER SET utf32 COLLATE utf32_hungarian_ci NOT NULL,
  `ugyfel_tel` varchar(12) CHARACTER SET utf32 COLLATE utf32_hungarian_ci NOT NULL,
  `munka_jell_id` tinyint(1) NOT NULL,
  `uzenet` tinytext CHARACTER SET utf32 COLLATE utf32_hungarian_ci NOT NULL,
  `statusz_id` tinyint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_hungarian_ci;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `munka_jell`
--

CREATE TABLE `munka_jell` (
  `id` tinyint(1) NOT NULL,
  `megnevezes` varchar(25) CHARACTER SET utf32 COLLATE utf32_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_hungarian_ci;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `statuszok`
--

CREATE TABLE `statuszok` (
  `id` tinyint NOT NULL,
  `megnevezes` varchar(25) CHARACTER SET utf32 COLLATE utf32_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_hungarian_ci;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `varosok`
--

CREATE TABLE `varosok` (
  `id` smallint NOT NULL,
  `iranyitoszam` smallint NOT NULL,
  `varos` varchar(30) CHARACTER SET utf32 COLLATE utf32_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_hungarian_ci;

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `megrendelesek`
--
ALTER TABLE `megrendelesek`
  ADD PRIMARY KEY (`id`),
  ADD KEY `statusz_id` (`statusz_id`),
  ADD KEY `munka_jell_id` (`munka_jell_id`),
  ADD KEY `varos_id` (`varos_id`);

--
-- A tábla indexei `munka_jell`
--
ALTER TABLE `munka_jell`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `statuszok`
--
ALTER TABLE `statuszok`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `varosok`
--
ALTER TABLE `varosok`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `megrendelesek`
--
ALTER TABLE `megrendelesek`
  MODIFY `id` mediumint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `munka_jell`
--
ALTER TABLE `munka_jell`
  MODIFY `id` tinyint(1) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `statuszok`
--
ALTER TABLE `statuszok`
  MODIFY `id` tinyint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `varosok`
--
ALTER TABLE `varosok`
  MODIFY `id` smallint NOT NULL AUTO_INCREMENT;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `megrendelesek`
--
ALTER TABLE `megrendelesek`
  ADD CONSTRAINT `megrendelesek_ibfk_1` FOREIGN KEY (`statusz_id`) REFERENCES `statuszok` (`id`),
  ADD CONSTRAINT `megrendelesek_ibfk_2` FOREIGN KEY (`munka_jell_id`) REFERENCES `munka_jell` (`id`),
  ADD CONSTRAINT `megrendelesek_ibfk_3` FOREIGN KEY (`varos_id`) REFERENCES `varosok` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
